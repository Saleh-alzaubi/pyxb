from pyxb.bundles.saml20.raw.x500 import *
