# ./pyxb/bundles/opengis/gml_3_3/raw/lrov.py
# -*- coding: utf-8 -*-
# PyXB bindings for NM:5cbc166911e5e674a32acb9aad7c39e239a33df9
# Generated 2020-02-05 11:35:44.448257 by PyXB version 1.2.6 using Python 2.7.17.final.0
# Namespace http://www.opengis.net/gml/3.3/lrov

from __future__ import unicode_literals
import pyxb
import pyxb.binding
import pyxb.binding.saxer
import io
import pyxb.utils.utility
import pyxb.utils.domutils
import sys
import pyxb.utils.six as _six
# Unique identifier for bindings created at the same time
_GenerationUID = pyxb.utils.utility.UniqueIdentifier('urn:uuid:6f22edd4-47af-11ea-ab78-1910708b4588')

# Version of PyXB used to generate the bindings
_PyXBVersion = '1.2.6'
# Generated bindings are not compatible across PyXB versions
if pyxb.__version__ != _PyXBVersion:
    raise pyxb.PyXBVersionError(_PyXBVersion)

# A holder for module-level binding classes so we can access them from
# inside class definitions where property names may conflict.
_module_typeBindings = pyxb.utils.utility.Object()

# Import bindings for namespaces imported into schema
from . import pyxb.bundles.opengis.gml_3_3.lro
from . import pyxb.binding.datatypes
from . import pyxb.bundles.common.xlink
from . import pyxb.bundles.opengis.gml_3_2
from . import pyxb.bundles.opengis.gml_3_3.lr

# NOTE: All namespace declarations are reserved within the binding
Namespace = pyxb.namespace.NamespaceForURI('http://www.opengis.net/gml/3.3/lrov', create_if_missing=True)
Namespace.configureCategories(['typeBinding', 'elementBinding'])
_Namespace_gml = pyxb.bundles.opengis.gml_3_2.Namespace
_Namespace_gml.configureCategories(['typeBinding', 'elementBinding'])
_Namespace = pyxb.bundles.common.xlink.Namespace
_Namespace.configureCategories(['typeBinding', 'elementBinding'])
_Namespace_gmllr = pyxb.bundles.opengis.gml_3_3.lr.Namespace
_Namespace_gmllr.configureCategories(['typeBinding', 'elementBinding'])

def CreateFromDocument (xml_text, default_namespace=None, location_base=None):
    """Parse the given XML and use the document element to create a
    Python instance.

    @param xml_text An XML document.  This should be data (Python 2
    str or Python 3 bytes), or a text (Python 2 unicode or Python 3
    str) in the L{pyxb._InputEncoding} encoding.

    @keyword default_namespace The L{pyxb.Namespace} instance to use as the
    default namespace where there is no default namespace in scope.
    If unspecified or C{None}, the namespace of the module containing
    this function will be used.

    @keyword location_base: An object to be recorded as the base of all
    L{pyxb.utils.utility.Location} instances associated with events and
    objects handled by the parser.  You might pass the URI from which
    the document was obtained.
    """

    if pyxb.XMLStyle_saxer != pyxb._XMLStyle:
        dom = pyxb.utils.domutils.StringToDOM(xml_text)
        return CreateFromDOM(dom.documentElement, default_namespace=default_namespace)
    if default_namespace is None:
        default_namespace = Namespace.fallbackNamespace()
    saxer = pyxb.binding.saxer.make_parser(fallback_namespace=default_namespace, location_base=location_base)
    handler = saxer.getContentHandler()
    xmld = xml_text
    if isinstance(xmld, _six.text_type):
        xmld = xmld.encode(pyxb._InputEncoding)
    saxer.parse(io.BytesIO(xmld))
    instance = handler.rootObject()
    return instance

def CreateFromDOM (node, default_namespace=None):
    """Create a Python instance from the given DOM node.
    The node tag must correspond to an element declaration in this module.

    @deprecated: Forcing use of DOM interface is unnecessary; use L{CreateFromDocument}."""
    if default_namespace is None:
        default_namespace = Namespace.fallbackNamespace()
    return pyxb.binding.basis.element.AnyCreateFromDOM(node, default_namespace)


# Complex type {http://www.opengis.net/gml/3.3/lrov}VectorOffsetExpressionType with content type ELEMENT_ONLY
class VectorOffsetExpressionType (pyxb.binding.basis.complexTypeDefinition):
    """Complex type {http://www.opengis.net/gml/3.3/lrov}VectorOffsetExpressionType with content type ELEMENT_ONLY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, 'VectorOffsetExpressionType')
    _XSDLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 18, 2)
    _ElementMap = {}
    _AttributeMap = {}
    # Base type is pyxb.binding.datatypes.anyType
    
    # Element {http://www.opengis.net/gml/3.3/lrov}offsetVector uses Python identifier offsetVector
    __offsetVector = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'offsetVector'), 'offsetVector', '__httpwww_opengis_netgml3_3lrov_VectorOffsetExpressionType_httpwww_opengis_netgml3_3lrovoffsetVector', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 20, 6), )

    
    offsetVector = property(__offsetVector.value, __offsetVector.set, None, None)

    _ElementMap.update({
        __offsetVector.name() : __offsetVector
    })
    _AttributeMap.update({
        
    })
_module_typeBindings.VectorOffsetExpressionType = VectorOffsetExpressionType
Namespace.addCategoryObject('typeBinding', 'VectorOffsetExpressionType', VectorOffsetExpressionType)


# Complex type {http://www.opengis.net/gml/3.3/lrov}VectorType with content type SIMPLE
class VectorType (pyxb.bundles.opengis.gml_3_2.VectorType):
    """Complex type {http://www.opengis.net/gml/3.3/lrov}VectorType with content type SIMPLE"""
    _TypeDefinition = pyxb.bundles.opengis.gml_3_2.STD_ANON_7
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_SIMPLE
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, 'VectorType')
    _XSDLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 35, 2)
    _ElementMap = pyxb.bundles.opengis.gml_3_2.VectorType._ElementMap.copy()
    _AttributeMap = pyxb.bundles.opengis.gml_3_2.VectorType._AttributeMap.copy()
    # Base type is pyxb.bundles.opengis.gml_3_2.VectorType
    
    # Attribute srsName inherited from {http://www.opengis.net/gml/3.2}DirectPositionType
    
    # Attribute srsDimension inherited from {http://www.opengis.net/gml/3.2}DirectPositionType
    
    # Attribute axisLabels inherited from {http://www.opengis.net/gml/3.2}DirectPositionType
    
    # Attribute uomLabels inherited from {http://www.opengis.net/gml/3.2}DirectPositionType
    
    # Attribute offsetUom uses Python identifier offsetUom
    __offsetUom = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, 'offsetUom'), 'offsetUom', '__httpwww_opengis_netgml3_3lrov_VectorType_offsetUom', pyxb.bundles.opengis.gml_3_2.UomIdentifier)
    __offsetUom._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 38, 8)
    __offsetUom._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 38, 8)
    
    offsetUom = property(__offsetUom.value, __offsetUom.set, None, None)

    _ElementMap.update({
        
    })
    _AttributeMap.update({
        __offsetUom.name() : __offsetUom
    })
_module_typeBindings.VectorType = VectorType
Namespace.addCategoryObject('typeBinding', 'VectorType', VectorType)


# Complex type {http://www.opengis.net/gml/3.3/lrov}VectorOffsetLinearSRSPropertyType with content type ELEMENT_ONLY
class VectorOffsetLinearSRSPropertyType (pyxb.binding.basis.complexTypeDefinition):
    """Complex type {http://www.opengis.net/gml/3.3/lrov}VectorOffsetLinearSRSPropertyType with content type ELEMENT_ONLY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, 'VectorOffsetLinearSRSPropertyType')
    _XSDLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 42, 2)
    _ElementMap = {}
    _AttributeMap = {}
    # Base type is pyxb.binding.datatypes.anyType
    
    # Element {http://www.opengis.net/gml/3.3/lrov}VectorOffsetLinearSRS uses Python identifier VectorOffsetLinearSRS
    __VectorOffsetLinearSRS = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'VectorOffsetLinearSRS'), 'VectorOffsetLinearSRS', '__httpwww_opengis_netgml3_3lrov_VectorOffsetLinearSRSPropertyType_httpwww_opengis_netgml3_3lrovVectorOffsetLinearSRS', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 34, 2), )

    
    VectorOffsetLinearSRS = property(__VectorOffsetLinearSRS.value, __VectorOffsetLinearSRS.set, None, None)

    
    # Attribute {http://www.opengis.net/gml/3.2}remoteSchema uses Python identifier remoteSchema
    __remoteSchema = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace_gml, 'remoteSchema'), 'remoteSchema', '__httpwww_opengis_netgml3_3lrov_VectorOffsetLinearSRSPropertyType_httpwww_opengis_netgml3_2remoteSchema', pyxb.binding.datatypes.anyURI)
    __remoteSchema._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/deprecatedTypes.xsd', 638, 1)
    __remoteSchema._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/gmlBase.xsd', 52, 2)
    
    remoteSchema = property(__remoteSchema.value, __remoteSchema.set, None, '')

    
    # Attribute nilReason uses Python identifier nilReason
    __nilReason = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, 'nilReason'), 'nilReason', '__httpwww_opengis_netgml3_3lrov_VectorOffsetLinearSRSPropertyType_nilReason', pyxb.bundles.opengis.gml_3_2.NilReasonType)
    __nilReason._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/gmlBase.xsd', 51, 2)
    __nilReason._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/gmlBase.xsd', 51, 2)
    
    nilReason = property(__nilReason.value, __nilReason.set, None, None)

    
    # Attribute {http://www.w3.org/1999/xlink}type uses Python identifier type
    __type = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace, 'type'), 'type', '__httpwww_opengis_netgml3_3lrov_VectorOffsetLinearSRSPropertyType_httpwww_w3_org1999xlinktype', pyxb.bundles.common.xlink.typeType, fixed=True, unicode_default='simple')
    __type._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 29, 1)
    __type._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 112, 2)
    
    type = property(__type.value, __type.set, None, None)

    
    # Attribute {http://www.w3.org/1999/xlink}href uses Python identifier href
    __href = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace, 'href'), 'href', '__httpwww_opengis_netgml3_3lrov_VectorOffsetLinearSRSPropertyType_httpwww_w3_org1999xlinkhref', pyxb.bundles.common.xlink.hrefType)
    __href._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 42, 1)
    __href._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 113, 2)
    
    href = property(__href.value, __href.set, None, None)

    
    # Attribute {http://www.w3.org/1999/xlink}role uses Python identifier role
    __role = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace, 'role'), 'role', '__httpwww_opengis_netgml3_3lrov_VectorOffsetLinearSRSPropertyType_httpwww_w3_org1999xlinkrole', pyxb.bundles.common.xlink.roleType)
    __role._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 48, 1)
    __role._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 114, 2)
    
    role = property(__role.value, __role.set, None, None)

    
    # Attribute {http://www.w3.org/1999/xlink}arcrole uses Python identifier arcrole
    __arcrole = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace, 'arcrole'), 'arcrole', '__httpwww_opengis_netgml3_3lrov_VectorOffsetLinearSRSPropertyType_httpwww_w3_org1999xlinkarcrole', pyxb.bundles.common.xlink.arcroleType)
    __arcrole._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 56, 1)
    __arcrole._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 115, 2)
    
    arcrole = property(__arcrole.value, __arcrole.set, None, None)

    
    # Attribute {http://www.w3.org/1999/xlink}title uses Python identifier title
    __title = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace, 'title'), 'title', '__httpwww_opengis_netgml3_3lrov_VectorOffsetLinearSRSPropertyType_httpwww_w3_org1999xlinktitle', pyxb.bundles.common.xlink.titleAttrType)
    __title._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 64, 1)
    __title._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 116, 2)
    
    title = property(__title.value, __title.set, None, None)

    
    # Attribute {http://www.w3.org/1999/xlink}show uses Python identifier show
    __show = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace, 'show'), 'show', '__httpwww_opengis_netgml3_3lrov_VectorOffsetLinearSRSPropertyType_httpwww_w3_org1999xlinkshow', pyxb.bundles.common.xlink.showType)
    __show._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 70, 1)
    __show._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 117, 2)
    
    show = property(__show.value, __show.set, None, None)

    
    # Attribute {http://www.w3.org/1999/xlink}actuate uses Python identifier actuate
    __actuate = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace, 'actuate'), 'actuate', '__httpwww_opengis_netgml3_3lrov_VectorOffsetLinearSRSPropertyType_httpwww_w3_org1999xlinkactuate', pyxb.bundles.common.xlink.actuateType)
    __actuate._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 82, 1)
    __actuate._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 118, 2)
    
    actuate = property(__actuate.value, __actuate.set, None, None)

    _ElementMap.update({
        __VectorOffsetLinearSRS.name() : __VectorOffsetLinearSRS
    })
    _AttributeMap.update({
        __remoteSchema.name() : __remoteSchema,
        __nilReason.name() : __nilReason,
        __type.name() : __type,
        __href.name() : __href,
        __role.name() : __role,
        __arcrole.name() : __arcrole,
        __title.name() : __title,
        __show.name() : __show,
        __actuate.name() : __actuate
    })
_module_typeBindings.VectorOffsetLinearSRSPropertyType = VectorOffsetLinearSRSPropertyType
Namespace.addCategoryObject('typeBinding', 'VectorOffsetLinearSRSPropertyType', VectorOffsetLinearSRSPropertyType)


# Complex type {http://www.opengis.net/gml/3.3/lrov}VectorOffsetDistanceExpressionType with content type ELEMENT_ONLY
class VectorOffsetDistanceExpressionType (pyxb.bundles.opengis.gml_3_3.lr.DistanceExpressionType):
    """Complex type {http://www.opengis.net/gml/3.3/lrov}VectorOffsetDistanceExpressionType with content type ELEMENT_ONLY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, 'VectorOffsetDistanceExpressionType')
    _XSDLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 8, 2)
    _ElementMap = pyxb.bundles.opengis.gml_3_3.lr.DistanceExpressionType._ElementMap.copy()
    _AttributeMap = pyxb.bundles.opengis.gml_3_3.lr.DistanceExpressionType._AttributeMap.copy()
    # Base type is pyxb.bundles.opengis.gml_3_3.lr.DistanceExpressionType
    
    # Element metaDataProperty ({http://www.opengis.net/gml/3.2}metaDataProperty) inherited from {http://www.opengis.net/gml/3.2}AbstractGMLType
    
    # Element description ({http://www.opengis.net/gml/3.2}description) inherited from {http://www.opengis.net/gml/3.2}AbstractGMLType
    
    # Element descriptionReference ({http://www.opengis.net/gml/3.2}descriptionReference) inherited from {http://www.opengis.net/gml/3.2}AbstractGMLType
    
    # Element name ({http://www.opengis.net/gml/3.2}name) inherited from {http://www.opengis.net/gml/3.2}AbstractGMLType
    
    # Element identifier ({http://www.opengis.net/gml/3.2}identifier) inherited from {http://www.opengis.net/gml/3.2}AbstractGMLType
    
    # Element distanceAlong ({http://www.opengis.net/gml/3.3/lr}distanceAlong) inherited from {http://www.opengis.net/gml/3.3/lr}DistanceExpressionType
    
    # Element referent ({http://www.opengis.net/gml/3.3/lr}referent) inherited from {http://www.opengis.net/gml/3.3/lr}DistanceExpressionType
    
    # Element {http://www.opengis.net/gml/3.3/lrov}vectorOffsetExpression uses Python identifier vectorOffsetExpression
    __vectorOffsetExpression = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'vectorOffsetExpression'), 'vectorOffsetExpression', '__httpwww_opengis_netgml3_3lrov_VectorOffsetDistanceExpressionType_httpwww_opengis_netgml3_3lrovvectorOffsetExpression', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 12, 10), )

    
    vectorOffsetExpression = property(__vectorOffsetExpression.value, __vectorOffsetExpression.set, None, None)

    
    # Attribute id inherited from {http://www.opengis.net/gml/3.2}AbstractGMLType
    _ElementMap.update({
        __vectorOffsetExpression.name() : __vectorOffsetExpression
    })
    _AttributeMap.update({
        
    })
_module_typeBindings.VectorOffsetDistanceExpressionType = VectorOffsetDistanceExpressionType
Namespace.addCategoryObject('typeBinding', 'VectorOffsetDistanceExpressionType', VectorOffsetDistanceExpressionType)


# Complex type {http://www.opengis.net/gml/3.3/lrov}VectorOffsetLinearSRSType with content type ELEMENT_ONLY
class VectorOffsetLinearSRSType (pyxb.bundles.opengis.gml_3_3.lr.LinearSRSType):
    """Complex type {http://www.opengis.net/gml/3.3/lrov}VectorOffsetLinearSRSType with content type ELEMENT_ONLY"""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, 'VectorOffsetLinearSRSType')
    _XSDLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 23, 2)
    _ElementMap = pyxb.bundles.opengis.gml_3_3.lr.LinearSRSType._ElementMap.copy()
    _AttributeMap = pyxb.bundles.opengis.gml_3_3.lr.LinearSRSType._AttributeMap.copy()
    # Base type is pyxb.bundles.opengis.gml_3_3.lr.LinearSRSType
    
    # Element metaDataProperty ({http://www.opengis.net/gml/3.2}metaDataProperty) inherited from {http://www.opengis.net/gml/3.2}AbstractGMLType
    
    # Element remarks ({http://www.opengis.net/gml/3.2}remarks) inherited from {http://www.opengis.net/gml/3.2}DefinitionType
    
    # Element description ({http://www.opengis.net/gml/3.2}description) inherited from {http://www.opengis.net/gml/3.2}AbstractGMLType
    
    # Element descriptionReference ({http://www.opengis.net/gml/3.2}descriptionReference) inherited from {http://www.opengis.net/gml/3.2}AbstractGMLType
    
    # Element name ({http://www.opengis.net/gml/3.2}name) inherited from {http://www.opengis.net/gml/3.2}AbstractGMLType
    
    # Element identifier ({http://www.opengis.net/gml/3.2}identifier) inherited from {http://www.opengis.net/gml/3.2}AbstractGMLType
    
    # Element linearElement ({http://www.opengis.net/gml/3.3/lr}linearElement) inherited from {http://www.opengis.net/gml/3.3/lr}LinearSRSType
    
    # Element lrm ({http://www.opengis.net/gml/3.3/lr}lrm) inherited from {http://www.opengis.net/gml/3.3/lr}LinearSRSType
    
    # Element {http://www.opengis.net/gml/3.3/lrov}linearElement uses Python identifier linearElement_
    __linearElement_ = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'linearElement'), 'linearElement_', '__httpwww_opengis_netgml3_3lrov_VectorOffsetLinearSRSType_httpwww_opengis_netgml3_3lrovlinearElement', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 27, 10), )

    
    linearElement_ = property(__linearElement_.value, __linearElement_.set, None, None)

    
    # Element {http://www.opengis.net/gml/3.3/lrov}lrm uses Python identifier lrm_
    __lrm_ = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'lrm'), 'lrm_', '__httpwww_opengis_netgml3_3lrov_VectorOffsetLinearSRSType_httpwww_opengis_netgml3_3lrovlrm', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 28, 10), )

    
    lrm_ = property(__lrm_.value, __lrm_.set, None, None)

    
    # Element {http://www.opengis.net/gml/3.3/lrov}offsetVector uses Python identifier offsetVector
    __offsetVector = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'offsetVector'), 'offsetVector', '__httpwww_opengis_netgml3_3lrov_VectorOffsetLinearSRSType_httpwww_opengis_netgml3_3lrovoffsetVector', True, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 29, 10), )

    
    offsetVector = property(__offsetVector.value, __offsetVector.set, None, None)

    
    # Attribute id_ inherited from {http://www.opengis.net/gml/3.2}DefinitionBaseType
    _ElementMap.update({
        __linearElement_.name() : __linearElement_,
        __lrm_.name() : __lrm_,
        __offsetVector.name() : __offsetVector
    })
    _AttributeMap.update({
        
    })
_module_typeBindings.VectorOffsetLinearSRSType = VectorOffsetLinearSRSType
Namespace.addCategoryObject('typeBinding', 'VectorOffsetLinearSRSType', VectorOffsetLinearSRSType)


VectorOffsetDistanceExpression = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'VectorOffsetDistanceExpression'), VectorOffsetDistanceExpressionType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 17, 2))
Namespace.addCategoryObject('elementBinding', VectorOffsetDistanceExpression.name().localName(), VectorOffsetDistanceExpression)

VectorOffsetLinearSRS = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'VectorOffsetLinearSRS'), VectorOffsetLinearSRSType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 34, 2))
Namespace.addCategoryObject('elementBinding', VectorOffsetLinearSRS.name().localName(), VectorOffsetLinearSRS)



VectorOffsetExpressionType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'offsetVector'), pyxb.bundles.opengis.gml_3_2.VectorType, scope=VectorOffsetExpressionType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 20, 6)))

def _BuildAutomaton ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton
    del _BuildAutomaton
    import pyxb.utils.fac as fac

    counters = set()
    states = []
    final_update = set()
    symbol = pyxb.binding.content.ElementUse(VectorOffsetExpressionType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'offsetVector')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 20, 6))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    transitions = []
    st_0._set_transitionSet(transitions)
    return fac.Automaton(states, counters, False, containing_state=None)
VectorOffsetExpressionType._Automaton = _BuildAutomaton()




VectorOffsetLinearSRSPropertyType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'VectorOffsetLinearSRS'), VectorOffsetLinearSRSType, scope=VectorOffsetLinearSRSPropertyType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 34, 2)))

def _BuildAutomaton_ ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton_
    del _BuildAutomaton_
    import pyxb.utils.fac as fac

    counters = set()
    cc_0 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 43, 4))
    counters.add(cc_0)
    states = []
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_0, False))
    symbol = pyxb.binding.content.ElementUse(VectorOffsetLinearSRSPropertyType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'VectorOffsetLinearSRS')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 44, 6))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    transitions = []
    transitions.append(fac.Transition(st_0, [
        fac.UpdateInstruction(cc_0, True) ]))
    st_0._set_transitionSet(transitions)
    return fac.Automaton(states, counters, True, containing_state=None)
VectorOffsetLinearSRSPropertyType._Automaton = _BuildAutomaton_()




VectorOffsetDistanceExpressionType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'vectorOffsetExpression'), VectorOffsetExpressionType, scope=VectorOffsetDistanceExpressionType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 12, 10)))

def _BuildAutomaton_2 ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton_2
    del _BuildAutomaton_2
    import pyxb.utils.fac as fac

    counters = set()
    cc_0 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/gmlBase.xsd', 39, 3))
    counters.add(cc_0)
    cc_1 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/gmlBase.xsd', 40, 3))
    counters.add(cc_1)
    cc_2 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/gmlBase.xsd', 41, 3))
    counters.add(cc_2)
    cc_3 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/gmlBase.xsd', 42, 3))
    counters.add(cc_3)
    cc_4 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/gmlBase.xsd', 43, 3))
    counters.add(cc_4)
    cc_5 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRef.xsd', 85, 10))
    counters.add(cc_5)
    cc_6 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 12, 10))
    counters.add(cc_6)
    states = []
    final_update = None
    symbol = pyxb.binding.content.ElementUse(VectorOffsetDistanceExpressionType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'metaDataProperty')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/gmlBase.xsd', 39, 3))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(VectorOffsetDistanceExpressionType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'description')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/gmlBase.xsd', 40, 3))
    st_1 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_1)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(VectorOffsetDistanceExpressionType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'descriptionReference')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/gmlBase.xsd', 41, 3))
    st_2 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_2)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(VectorOffsetDistanceExpressionType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'identifier')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/gmlBase.xsd', 42, 3))
    st_3 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_3)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(VectorOffsetDistanceExpressionType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'name')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/gmlBase.xsd', 43, 3))
    st_4 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_4)
    final_update = set()
    symbol = pyxb.binding.content.ElementUse(VectorOffsetDistanceExpressionType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gmllr, 'distanceAlong')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRef.xsd', 84, 10))
    st_5 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_5)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_5, False))
    symbol = pyxb.binding.content.ElementUse(VectorOffsetDistanceExpressionType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gmllr, 'referent')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRef.xsd', 85, 10))
    st_6 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_6)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_6, False))
    symbol = pyxb.binding.content.ElementUse(VectorOffsetDistanceExpressionType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'vectorOffsetExpression')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 12, 10))
    st_7 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_7)
    transitions = []
    transitions.append(fac.Transition(st_0, [
        fac.UpdateInstruction(cc_0, True) ]))
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_0, False) ]))
    st_0._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_1, True) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_1, False) ]))
    st_1._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_2, True) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_2, False) ]))
    st_2._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_3, True) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_3, False) ]))
    st_3._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_4, True) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_4, False) ]))
    st_4._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_6, [
         ]))
    transitions.append(fac.Transition(st_7, [
         ]))
    st_5._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_5, True) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_5, False) ]))
    st_6._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_6, True) ]))
    st_7._set_transitionSet(transitions)
    return fac.Automaton(states, counters, False, containing_state=None)
VectorOffsetDistanceExpressionType._Automaton = _BuildAutomaton_2()




VectorOffsetLinearSRSType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'linearElement'), pyxb.bundles.opengis.gml_3_3.lr.LinearElementPropertyType, scope=VectorOffsetLinearSRSType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 27, 10)))

VectorOffsetLinearSRSType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'lrm'), pyxb.bundles.opengis.gml_3_3.lro.LRMWithOffsetPropertyType, scope=VectorOffsetLinearSRSType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 28, 10)))

VectorOffsetLinearSRSType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'offsetVector'), VectorType, scope=VectorOffsetLinearSRSType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 29, 10)))

def _BuildAutomaton_3 ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton_3
    del _BuildAutomaton_3
    import pyxb.utils.fac as fac

    counters = set()
    cc_0 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/dictionary.xsd', 35, 5))
    counters.add(cc_0)
    cc_1 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/dictionary.xsd', 36, 5))
    counters.add(cc_1)
    cc_2 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/dictionary.xsd', 37, 5))
    counters.add(cc_2)
    cc_3 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/dictionary.xsd', 39, 5))
    counters.add(cc_3)
    cc_4 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/dictionary.xsd', 49, 5))
    counters.add(cc_4)
    cc_5 = fac.CounterCondition(min=1, max=3, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 29, 10))
    counters.add(cc_5)
    states = []
    final_update = None
    symbol = pyxb.binding.content.ElementUse(VectorOffsetLinearSRSType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'metaDataProperty')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/dictionary.xsd', 35, 5))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(VectorOffsetLinearSRSType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'description')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/dictionary.xsd', 36, 5))
    st_1 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_1)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(VectorOffsetLinearSRSType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'descriptionReference')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/dictionary.xsd', 37, 5))
    st_2 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_2)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(VectorOffsetLinearSRSType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'identifier')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/dictionary.xsd', 38, 5))
    st_3 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_3)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(VectorOffsetLinearSRSType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'name')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/dictionary.xsd', 39, 5))
    st_4 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_4)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(VectorOffsetLinearSRSType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'remarks')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.2.1/dictionary.xsd', 49, 5))
    st_5 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_5)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(VectorOffsetLinearSRSType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gmllr, 'linearElement')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRef.xsd', 202, 10))
    st_6 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_6)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(VectorOffsetLinearSRSType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gmllr, 'lrm')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRef.xsd', 203, 10))
    st_7 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_7)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(VectorOffsetLinearSRSType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'linearElement')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 27, 10))
    st_8 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_8)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(VectorOffsetLinearSRSType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'lrm')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 28, 10))
    st_9 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_9)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_5, False))
    symbol = pyxb.binding.content.ElementUse(VectorOffsetLinearSRSType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'offsetVector')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.3/linearRefOffsetVector.xsd', 29, 10))
    st_10 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_10)
    transitions = []
    transitions.append(fac.Transition(st_0, [
        fac.UpdateInstruction(cc_0, True) ]))
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_0, False) ]))
    st_0._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_1, True) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_1, False) ]))
    st_1._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_2, True) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_2, False) ]))
    st_2._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_4, [
         ]))
    transitions.append(fac.Transition(st_5, [
         ]))
    transitions.append(fac.Transition(st_6, [
         ]))
    st_3._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_3, True) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_3, False) ]))
    st_4._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_4, True) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_4, False) ]))
    st_5._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_7, [
         ]))
    st_6._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_8, [
         ]))
    st_7._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_9, [
         ]))
    st_8._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_10, [
         ]))
    st_9._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_10, [
        fac.UpdateInstruction(cc_5, True) ]))
    st_10._set_transitionSet(transitions)
    return fac.Automaton(states, counters, False, containing_state=None)
VectorOffsetLinearSRSType._Automaton = _BuildAutomaton_3()


VectorOffsetDistanceExpression._setSubstitutionGroup(pyxb.bundles.opengis.gml_3_3.lr.DistanceExpression)

VectorOffsetLinearSRS._setSubstitutionGroup(pyxb.bundles.opengis.gml_3_3.lr.LinearSRS)
