# -*- coding: utf-8 -*-
from pyxb.bundles.opengis.raw.wps_1_0_0 import *
