# -*- coding: utf-8 -*-
from pyxb.bundles.opengis.raw.oseo_1_0 import *
