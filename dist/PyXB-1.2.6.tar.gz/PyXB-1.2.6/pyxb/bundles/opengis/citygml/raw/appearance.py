# ./pyxb/bundles/opengis/citygml/raw/appearance.py
# -*- coding: utf-8 -*-
# PyXB bindings for NM:4eab4d25f54c999b91cd172921f2cc6ee7e6addb
# Generated 2020-02-05 11:34:28.474909 by PyXB version 1.2.6 using Python 2.7.17.final.0
# Namespace http://www.opengis.net/citygml/appearance/1.0

from __future__ import unicode_literals
import pyxb
import pyxb.binding
import pyxb.binding.saxer
import io
import pyxb.utils.utility
import pyxb.utils.domutils
import sys
import pyxb.utils.six as _six
# Unique identifier for bindings created at the same time
_GenerationUID = pyxb.utils.utility.UniqueIdentifier('urn:uuid:42be6412-47af-11ea-ab78-1910708b4588')

# Version of PyXB used to generate the bindings
_PyXBVersion = '1.2.6'
# Generated bindings are not compatible across PyXB versions
if pyxb.__version__ != _PyXBVersion:
    raise pyxb.PyXBVersionError(_PyXBVersion)

# A holder for module-level binding classes so we can access them from
# inside class definitions where property names may conflict.
_module_typeBindings = pyxb.utils.utility.Object()

# Import bindings for namespaces imported into schema
from . import pyxb.bundles.opengis.citygml.base
from . import pyxb.bundles.common.xlink
from . import pyxb.binding.datatypes
from . import pyxb.bundles.opengis.gml

# NOTE: All namespace declarations are reserved within the binding
Namespace = pyxb.namespace.NamespaceForURI('http://www.opengis.net/citygml/appearance/1.0', create_if_missing=True)
Namespace.configureCategories(['typeBinding', 'elementBinding'])
_Namespace_gml = pyxb.bundles.opengis.gml.Namespace
_Namespace_gml.configureCategories(['typeBinding', 'elementBinding'])
_Namespace = pyxb.bundles.common.xlink.Namespace
_Namespace.configureCategories(['typeBinding', 'elementBinding'])

def CreateFromDocument (xml_text, default_namespace=None, location_base=None):
    """Parse the given XML and use the document element to create a
    Python instance.

    @param xml_text An XML document.  This should be data (Python 2
    str or Python 3 bytes), or a text (Python 2 unicode or Python 3
    str) in the L{pyxb._InputEncoding} encoding.

    @keyword default_namespace The L{pyxb.Namespace} instance to use as the
    default namespace where there is no default namespace in scope.
    If unspecified or C{None}, the namespace of the module containing
    this function will be used.

    @keyword location_base: An object to be recorded as the base of all
    L{pyxb.utils.utility.Location} instances associated with events and
    objects handled by the parser.  You might pass the URI from which
    the document was obtained.
    """

    if pyxb.XMLStyle_saxer != pyxb._XMLStyle:
        dom = pyxb.utils.domutils.StringToDOM(xml_text)
        return CreateFromDOM(dom.documentElement, default_namespace=default_namespace)
    if default_namespace is None:
        default_namespace = Namespace.fallbackNamespace()
    saxer = pyxb.binding.saxer.make_parser(fallback_namespace=default_namespace, location_base=location_base)
    handler = saxer.getContentHandler()
    xmld = xml_text
    if isinstance(xmld, _six.text_type):
        xmld = xmld.encode(pyxb._InputEncoding)
    saxer.parse(io.BytesIO(xmld))
    instance = handler.rootObject()
    return instance

def CreateFromDOM (node, default_namespace=None):
    """Create a Python instance from the given DOM node.
    The node tag must correspond to an element declaration in this module.

    @deprecated: Forcing use of DOM interface is unnecessary; use L{CreateFromDocument}."""
    if default_namespace is None:
        default_namespace = Namespace.fallbackNamespace()
    return pyxb.binding.basis.element.AnyCreateFromDOM(node, default_namespace)


# Atomic simple type: {http://www.opengis.net/citygml/appearance/1.0}WrapModeType
class WrapModeType (pyxb.binding.datatypes.string, pyxb.binding.basis.enumeration_mixin):

    """Fill mode for a texture. "wrap" repeats the texture, "clamp" extends the edges of the texture, and
                "border" fills all undefined areas with "borderColor" """

    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, 'WrapModeType')
    _XSDLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 108, 4)
    _Documentation = 'Fill mode for a texture. "wrap" repeats the texture, "clamp" extends the edges of the texture, and\n                "border" fills all undefined areas with "borderColor"'
WrapModeType._CF_enumeration = pyxb.binding.facets.CF_enumeration(value_datatype=WrapModeType, enum_prefix=None)
WrapModeType.none = WrapModeType._CF_enumeration.addEnumeration(unicode_value='none', tag='none')
WrapModeType.wrap = WrapModeType._CF_enumeration.addEnumeration(unicode_value='wrap', tag='wrap')
WrapModeType.mirror = WrapModeType._CF_enumeration.addEnumeration(unicode_value='mirror', tag='mirror')
WrapModeType.clamp = WrapModeType._CF_enumeration.addEnumeration(unicode_value='clamp', tag='clamp')
WrapModeType.border = WrapModeType._CF_enumeration.addEnumeration(unicode_value='border', tag='border')
WrapModeType._InitializeFacetMap(WrapModeType._CF_enumeration)
Namespace.addCategoryObject('typeBinding', 'WrapModeType', WrapModeType)
_module_typeBindings.WrapModeType = WrapModeType

# Atomic simple type: {http://www.opengis.net/citygml/appearance/1.0}TextureTypeType
class TextureTypeType (pyxb.binding.datatypes.string, pyxb.binding.basis.enumeration_mixin):

    """Textures can be qualified by the attribute textureType. The textureType differentiates between
                textures, which are specific for a certain object and are only used for that object (specific), and prototypic
                textures being typical for that kind of object and are used many times for all objects of that kind (typical). A
                typical texture may be replaced by a specific, if available. Textures may also be classified as unknown.
            """

    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, 'TextureTypeType')
    _XSDLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 294, 4)
    _Documentation = 'Textures can be qualified by the attribute textureType. The textureType differentiates between\n                textures, which are specific for a certain object and are only used for that object (specific), and prototypic\n                textures being typical for that kind of object and are used many times for all objects of that kind (typical). A\n                typical texture may be replaced by a specific, if available. Textures may also be classified as unknown.\n            '
TextureTypeType._CF_enumeration = pyxb.binding.facets.CF_enumeration(value_datatype=TextureTypeType, enum_prefix=None)
TextureTypeType.specific = TextureTypeType._CF_enumeration.addEnumeration(unicode_value='specific', tag='specific')
TextureTypeType.typical = TextureTypeType._CF_enumeration.addEnumeration(unicode_value='typical', tag='typical')
TextureTypeType.unknown = TextureTypeType._CF_enumeration.addEnumeration(unicode_value='unknown', tag='unknown')
TextureTypeType._InitializeFacetMap(TextureTypeType._CF_enumeration)
Namespace.addCategoryObject('typeBinding', 'TextureTypeType', TextureTypeType)
_module_typeBindings.TextureTypeType = TextureTypeType

# List simple type: {http://www.opengis.net/citygml/appearance/1.0}Color
# superclasses pyxb.bundles.opengis.citygml.base.doubleBetween0and1List
class Color (pyxb.binding.basis.STD_list):

    """List of three values (red, green, blue), separated by spaces. The values must be in the range
                between zero and one. """

    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, 'Color')
    _XSDLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 309, 4)
    _Documentation = 'List of three values (red, green, blue), separated by spaces. The values must be in the range\n                between zero and one. '

    _ItemType = pyxb.bundles.opengis.citygml.base.doubleBetween0and1
Color._CF_length = pyxb.binding.facets.CF_length(value=pyxb.binding.datatypes.nonNegativeInteger(3))
Color._InitializeFacetMap(Color._CF_length)
Namespace.addCategoryObject('typeBinding', 'Color', Color)
_module_typeBindings.Color = Color

# List simple type: {http://www.opengis.net/citygml/appearance/1.0}ColorPlusOpacity
# superclasses pyxb.bundles.opengis.citygml.base.doubleBetween0and1List
class ColorPlusOpacity (pyxb.binding.basis.STD_list):

    """List of three or four values (red, green, blue, opacity), separated by spaces. The values must be in
                the range between zero and one. If no opacity is given, it is assumed as 1.0."""

    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, 'ColorPlusOpacity')
    _XSDLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 319, 4)
    _Documentation = 'List of three or four values (red, green, blue, opacity), separated by spaces. The values must be in\n                the range between zero and one. If no opacity is given, it is assumed as 1.0.'

    _ItemType = pyxb.bundles.opengis.citygml.base.doubleBetween0and1
ColorPlusOpacity._CF_minLength = pyxb.binding.facets.CF_minLength(value=pyxb.binding.datatypes.nonNegativeInteger(3))
ColorPlusOpacity._CF_maxLength = pyxb.binding.facets.CF_maxLength(value=pyxb.binding.datatypes.nonNegativeInteger(4))
ColorPlusOpacity._InitializeFacetMap(ColorPlusOpacity._CF_minLength,
   ColorPlusOpacity._CF_maxLength)
Namespace.addCategoryObject('typeBinding', 'ColorPlusOpacity', ColorPlusOpacity)
_module_typeBindings.ColorPlusOpacity = ColorPlusOpacity

# Complex type {http://www.opengis.net/citygml/appearance/1.0}AppearanceType with content type ELEMENT_ONLY
class AppearanceType (pyxb.bundles.opengis.gml.AbstractFeatureType):
    """ Named container for all surface data (texture/material). All appearances of the same name ("theme")
                within a CityGML file are considered a group. """
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, 'AppearanceType')
    _XSDLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 17, 4)
    _ElementMap = pyxb.bundles.opengis.gml.AbstractFeatureType._ElementMap.copy()
    _AttributeMap = pyxb.bundles.opengis.gml.AbstractFeatureType._AttributeMap.copy()
    # Base type is pyxb.bundles.opengis.gml.AbstractFeatureType
    
    # Element {http://www.opengis.net/citygml/appearance/1.0}theme uses Python identifier theme
    __theme = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'theme'), 'theme', '__httpwww_opengis_netcitygmlappearance1_0_AppearanceType_httpwww_opengis_netcitygmlappearance1_0theme', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 25, 20), )

    
    theme = property(__theme.value, __theme.set, None, None)

    
    # Element {http://www.opengis.net/citygml/appearance/1.0}surfaceDataMember uses Python identifier surfaceDataMember
    __surfaceDataMember = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'surfaceDataMember'), 'surfaceDataMember', '__httpwww_opengis_netcitygmlappearance1_0_AppearanceType_httpwww_opengis_netcitygmlappearance1_0surfaceDataMember', True, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 26, 20), )

    
    surfaceDataMember = property(__surfaceDataMember.value, __surfaceDataMember.set, None, None)

    
    # Element {http://www.opengis.net/citygml/appearance/1.0}_GenericApplicationPropertyOfAppearance uses Python identifier GenericApplicationPropertyOfAppearance
    __GenericApplicationPropertyOfAppearance = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfAppearance'), 'GenericApplicationPropertyOfAppearance', '__httpwww_opengis_netcitygmlappearance1_0_AppearanceType_httpwww_opengis_netcitygmlappearance1_0_GenericApplicationPropertyOfAppearance', True, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 33, 4), )

    
    GenericApplicationPropertyOfAppearance = property(__GenericApplicationPropertyOfAppearance.value, __GenericApplicationPropertyOfAppearance.set, None, None)

    
    # Element boundedBy ({http://www.opengis.net/gml}boundedBy) inherited from {http://www.opengis.net/gml}AbstractFeatureType
    
    # Element location ({http://www.opengis.net/gml}location) inherited from {http://www.opengis.net/gml}AbstractFeatureType
    
    # Element metaDataProperty ({http://www.opengis.net/gml}metaDataProperty) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Element name ({http://www.opengis.net/gml}name) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Element description ({http://www.opengis.net/gml}description) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Attribute id inherited from {http://www.opengis.net/gml}AbstractGMLType
    _ElementMap.update({
        __theme.name() : __theme,
        __surfaceDataMember.name() : __surfaceDataMember,
        __GenericApplicationPropertyOfAppearance.name() : __GenericApplicationPropertyOfAppearance
    })
    _AttributeMap.update({
        
    })
_module_typeBindings.AppearanceType = AppearanceType
Namespace.addCategoryObject('typeBinding', 'AppearanceType', AppearanceType)


# Complex type {http://www.opengis.net/citygml/appearance/1.0}AppearancePropertyType with content type ELEMENT_ONLY
class AppearancePropertyType (pyxb.bundles.opengis.gml.FeaturePropertyType):
    """Denotes the relation of a _CityObject resp. CityModel to its appearances. The AppearancePropertyType
                element must either carry a reference to a Appearance object or contain a Appearance object inline, but neither
                both nor none."""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, 'AppearancePropertyType')
    _XSDLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 35, 4)
    _ElementMap = pyxb.bundles.opengis.gml.FeaturePropertyType._ElementMap.copy()
    _AttributeMap = pyxb.bundles.opengis.gml.FeaturePropertyType._AttributeMap.copy()
    # Base type is pyxb.bundles.opengis.gml.FeaturePropertyType
    
    # Element {http://www.opengis.net/citygml/appearance/1.0}Appearance uses Python identifier Appearance
    __Appearance = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'Appearance'), 'Appearance', '__httpwww_opengis_netcitygmlappearance1_0_AppearancePropertyType_httpwww_opengis_netcitygmlappearance1_0Appearance', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 44, 20), )

    
    Appearance = property(__Appearance.value, __Appearance.set, None, None)

    
    # Element Feature ({http://www.opengis.net/gml}_Feature) inherited from {http://www.opengis.net/gml}FeaturePropertyType
    
    # Attribute remoteSchema inherited from {http://www.opengis.net/gml}FeaturePropertyType
    
    # Attribute type inherited from {http://www.opengis.net/gml}FeaturePropertyType
    
    # Attribute href inherited from {http://www.opengis.net/gml}FeaturePropertyType
    
    # Attribute role inherited from {http://www.opengis.net/gml}FeaturePropertyType
    
    # Attribute arcrole inherited from {http://www.opengis.net/gml}FeaturePropertyType
    
    # Attribute title inherited from {http://www.opengis.net/gml}FeaturePropertyType
    
    # Attribute show inherited from {http://www.opengis.net/gml}FeaturePropertyType
    
    # Attribute actuate inherited from {http://www.opengis.net/gml}FeaturePropertyType
    _ElementMap.update({
        __Appearance.name() : __Appearance
    })
    _AttributeMap.update({
        
    })
_module_typeBindings.AppearancePropertyType = AppearancePropertyType
Namespace.addCategoryObject('typeBinding', 'AppearancePropertyType', AppearancePropertyType)


# Complex type {http://www.opengis.net/citygml/appearance/1.0}AbstractSurfaceDataType with content type ELEMENT_ONLY
class AbstractSurfaceDataType (pyxb.bundles.opengis.gml.AbstractFeatureType):
    """Base class for textures and material. Contains only isFront-flag."""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, 'AbstractSurfaceDataType')
    _XSDLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 54, 4)
    _ElementMap = pyxb.bundles.opengis.gml.AbstractFeatureType._ElementMap.copy()
    _AttributeMap = pyxb.bundles.opengis.gml.AbstractFeatureType._AttributeMap.copy()
    # Base type is pyxb.bundles.opengis.gml.AbstractFeatureType
    
    # Element {http://www.opengis.net/citygml/appearance/1.0}isFront uses Python identifier isFront
    __isFront = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'isFront'), 'isFront', '__httpwww_opengis_netcitygmlappearance1_0_AbstractSurfaceDataType_httpwww_opengis_netcitygmlappearance1_0isFront', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 61, 20), )

    
    isFront = property(__isFront.value, __isFront.set, None, None)

    
    # Element {http://www.opengis.net/citygml/appearance/1.0}_GenericApplicationPropertyOfSurfaceData uses Python identifier GenericApplicationPropertyOfSurfaceData
    __GenericApplicationPropertyOfSurfaceData = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfSurfaceData'), 'GenericApplicationPropertyOfSurfaceData', '__httpwww_opengis_netcitygmlappearance1_0_AbstractSurfaceDataType_httpwww_opengis_netcitygmlappearance1_0_GenericApplicationPropertyOfSurfaceData', True, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 70, 4), )

    
    GenericApplicationPropertyOfSurfaceData = property(__GenericApplicationPropertyOfSurfaceData.value, __GenericApplicationPropertyOfSurfaceData.set, None, None)

    
    # Element boundedBy ({http://www.opengis.net/gml}boundedBy) inherited from {http://www.opengis.net/gml}AbstractFeatureType
    
    # Element location ({http://www.opengis.net/gml}location) inherited from {http://www.opengis.net/gml}AbstractFeatureType
    
    # Element metaDataProperty ({http://www.opengis.net/gml}metaDataProperty) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Element name ({http://www.opengis.net/gml}name) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Element description ({http://www.opengis.net/gml}description) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Attribute id inherited from {http://www.opengis.net/gml}AbstractGMLType
    _ElementMap.update({
        __isFront.name() : __isFront,
        __GenericApplicationPropertyOfSurfaceData.name() : __GenericApplicationPropertyOfSurfaceData
    })
    _AttributeMap.update({
        
    })
_module_typeBindings.AbstractSurfaceDataType = AbstractSurfaceDataType
Namespace.addCategoryObject('typeBinding', 'AbstractSurfaceDataType', AbstractSurfaceDataType)


# Complex type {http://www.opengis.net/citygml/appearance/1.0}SurfaceDataPropertyType with content type ELEMENT_ONLY
class SurfaceDataPropertyType (pyxb.binding.basis.complexTypeDefinition):
    """Denotes the relation of an Appearance to its surface data. The SurfaceDataPropertyType element must
                either carry a reference to a _SurfaceData object or contain a _SurfaceData object inline, but neither both nor
                none."""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, 'SurfaceDataPropertyType')
    _XSDLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 72, 4)
    _ElementMap = {}
    _AttributeMap = {}
    # Base type is pyxb.binding.datatypes.anyType
    
    # Element {http://www.opengis.net/citygml/appearance/1.0}_SurfaceData uses Python identifier SurfaceData
    __SurfaceData = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, '_SurfaceData'), 'SurfaceData', '__httpwww_opengis_netcitygmlappearance1_0_SurfaceDataPropertyType_httpwww_opengis_netcitygmlappearance1_0_SurfaceData', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 68, 4), )

    
    SurfaceData = property(__SurfaceData.value, __SurfaceData.set, None, None)

    
    # Attribute {http://www.opengis.net/gml}remoteSchema uses Python identifier remoteSchema
    __remoteSchema = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace_gml, 'remoteSchema'), 'remoteSchema', '__httpwww_opengis_netcitygmlappearance1_0_SurfaceDataPropertyType_httpwww_opengis_netgmlremoteSchema', pyxb.binding.datatypes.anyURI)
    __remoteSchema._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 258, 1)
    __remoteSchema._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 269, 2)
    
    remoteSchema = property(__remoteSchema.value, __remoteSchema.set, None, 'Reference to an XML Schema fragment that specifies the content model of the propertys value. This is in conformance with the XML Schema Section 4.14 Referencing Schemas from Elsewhere.')

    
    # Attribute {http://www.w3.org/1999/xlink}type uses Python identifier type
    __type = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace, 'type'), 'type', '__httpwww_opengis_netcitygmlappearance1_0_SurfaceDataPropertyType_httpwww_w3_org1999xlinktype', pyxb.bundles.common.xlink.typeType, fixed=True, unicode_default='simple')
    __type._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 29, 1)
    __type._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 112, 2)
    
    type = property(__type.value, __type.set, None, None)

    
    # Attribute {http://www.w3.org/1999/xlink}href uses Python identifier href
    __href = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace, 'href'), 'href', '__httpwww_opengis_netcitygmlappearance1_0_SurfaceDataPropertyType_httpwww_w3_org1999xlinkhref', pyxb.bundles.common.xlink.hrefType)
    __href._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 42, 1)
    __href._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 113, 2)
    
    href = property(__href.value, __href.set, None, None)

    
    # Attribute {http://www.w3.org/1999/xlink}role uses Python identifier role
    __role = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace, 'role'), 'role', '__httpwww_opengis_netcitygmlappearance1_0_SurfaceDataPropertyType_httpwww_w3_org1999xlinkrole', pyxb.bundles.common.xlink.roleType)
    __role._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 48, 1)
    __role._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 114, 2)
    
    role = property(__role.value, __role.set, None, None)

    
    # Attribute {http://www.w3.org/1999/xlink}arcrole uses Python identifier arcrole
    __arcrole = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace, 'arcrole'), 'arcrole', '__httpwww_opengis_netcitygmlappearance1_0_SurfaceDataPropertyType_httpwww_w3_org1999xlinkarcrole', pyxb.bundles.common.xlink.arcroleType)
    __arcrole._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 56, 1)
    __arcrole._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 115, 2)
    
    arcrole = property(__arcrole.value, __arcrole.set, None, None)

    
    # Attribute {http://www.w3.org/1999/xlink}title uses Python identifier title
    __title = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace, 'title'), 'title', '__httpwww_opengis_netcitygmlappearance1_0_SurfaceDataPropertyType_httpwww_w3_org1999xlinktitle', pyxb.bundles.common.xlink.titleAttrType)
    __title._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 64, 1)
    __title._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 116, 2)
    
    title = property(__title.value, __title.set, None, None)

    
    # Attribute {http://www.w3.org/1999/xlink}show uses Python identifier show
    __show = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace, 'show'), 'show', '__httpwww_opengis_netcitygmlappearance1_0_SurfaceDataPropertyType_httpwww_w3_org1999xlinkshow', pyxb.bundles.common.xlink.showType)
    __show._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 70, 1)
    __show._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 117, 2)
    
    show = property(__show.value, __show.set, None, None)

    
    # Attribute {http://www.w3.org/1999/xlink}actuate uses Python identifier actuate
    __actuate = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace, 'actuate'), 'actuate', '__httpwww_opengis_netcitygmlappearance1_0_SurfaceDataPropertyType_httpwww_w3_org1999xlinkactuate', pyxb.bundles.common.xlink.actuateType)
    __actuate._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 82, 1)
    __actuate._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 118, 2)
    
    actuate = property(__actuate.value, __actuate.set, None, None)

    _ElementMap.update({
        __SurfaceData.name() : __SurfaceData
    })
    _AttributeMap.update({
        __remoteSchema.name() : __remoteSchema,
        __type.name() : __type,
        __href.name() : __href,
        __role.name() : __role,
        __arcrole.name() : __arcrole,
        __title.name() : __title,
        __show.name() : __show,
        __actuate.name() : __actuate
    })
_module_typeBindings.SurfaceDataPropertyType = SurfaceDataPropertyType
Namespace.addCategoryObject('typeBinding', 'SurfaceDataPropertyType', SurfaceDataPropertyType)


# Complex type {http://www.opengis.net/citygml/appearance/1.0}TextureAssociationType with content type ELEMENT_ONLY
class TextureAssociationType (pyxb.binding.basis.complexTypeDefinition):
    """Denotes the relation of a texture to a surface, that is augmented by a TextureParameterization
                object. The TextureAssociationType element must either carry a reference to a _TextureParameterization object or
                contain a _TextureParameterization object inline, but neither both nor none."""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, 'TextureAssociationType')
    _XSDLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 172, 4)
    _ElementMap = {}
    _AttributeMap = {}
    # Base type is pyxb.binding.datatypes.anyType
    
    # Element {http://www.opengis.net/citygml/appearance/1.0}_TextureParameterization uses Python identifier TextureParameterization
    __TextureParameterization = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, '_TextureParameterization'), 'TextureParameterization', '__httpwww_opengis_netcitygmlappearance1_0_TextureAssociationType_httpwww_opengis_netcitygmlappearance1_0_TextureParameterization', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 200, 4), )

    
    TextureParameterization = property(__TextureParameterization.value, __TextureParameterization.set, None, None)

    
    # Attribute uri uses Python identifier uri
    __uri = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, 'uri'), 'uri', '__httpwww_opengis_netcitygmlappearance1_0_TextureAssociationType_uri', pyxb.binding.datatypes.anyURI, required=True)
    __uri._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 181, 8)
    __uri._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 181, 8)
    
    uri = property(__uri.value, __uri.set, None, None)

    
    # Attribute {http://www.opengis.net/gml}remoteSchema uses Python identifier remoteSchema
    __remoteSchema = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace_gml, 'remoteSchema'), 'remoteSchema', '__httpwww_opengis_netcitygmlappearance1_0_TextureAssociationType_httpwww_opengis_netgmlremoteSchema', pyxb.binding.datatypes.anyURI)
    __remoteSchema._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 258, 1)
    __remoteSchema._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 269, 2)
    
    remoteSchema = property(__remoteSchema.value, __remoteSchema.set, None, 'Reference to an XML Schema fragment that specifies the content model of the propertys value. This is in conformance with the XML Schema Section 4.14 Referencing Schemas from Elsewhere.')

    
    # Attribute {http://www.w3.org/1999/xlink}type uses Python identifier type
    __type = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace, 'type'), 'type', '__httpwww_opengis_netcitygmlappearance1_0_TextureAssociationType_httpwww_w3_org1999xlinktype', pyxb.bundles.common.xlink.typeType, fixed=True, unicode_default='simple')
    __type._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 29, 1)
    __type._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 112, 2)
    
    type = property(__type.value, __type.set, None, None)

    
    # Attribute {http://www.w3.org/1999/xlink}href uses Python identifier href
    __href = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace, 'href'), 'href', '__httpwww_opengis_netcitygmlappearance1_0_TextureAssociationType_httpwww_w3_org1999xlinkhref', pyxb.bundles.common.xlink.hrefType)
    __href._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 42, 1)
    __href._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 113, 2)
    
    href = property(__href.value, __href.set, None, None)

    
    # Attribute {http://www.w3.org/1999/xlink}role uses Python identifier role
    __role = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace, 'role'), 'role', '__httpwww_opengis_netcitygmlappearance1_0_TextureAssociationType_httpwww_w3_org1999xlinkrole', pyxb.bundles.common.xlink.roleType)
    __role._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 48, 1)
    __role._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 114, 2)
    
    role = property(__role.value, __role.set, None, None)

    
    # Attribute {http://www.w3.org/1999/xlink}arcrole uses Python identifier arcrole
    __arcrole = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace, 'arcrole'), 'arcrole', '__httpwww_opengis_netcitygmlappearance1_0_TextureAssociationType_httpwww_w3_org1999xlinkarcrole', pyxb.bundles.common.xlink.arcroleType)
    __arcrole._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 56, 1)
    __arcrole._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 115, 2)
    
    arcrole = property(__arcrole.value, __arcrole.set, None, None)

    
    # Attribute {http://www.w3.org/1999/xlink}title uses Python identifier title
    __title = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace, 'title'), 'title', '__httpwww_opengis_netcitygmlappearance1_0_TextureAssociationType_httpwww_w3_org1999xlinktitle', pyxb.bundles.common.xlink.titleAttrType)
    __title._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 64, 1)
    __title._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 116, 2)
    
    title = property(__title.value, __title.set, None, None)

    
    # Attribute {http://www.w3.org/1999/xlink}show uses Python identifier show
    __show = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace, 'show'), 'show', '__httpwww_opengis_netcitygmlappearance1_0_TextureAssociationType_httpwww_w3_org1999xlinkshow', pyxb.bundles.common.xlink.showType)
    __show._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 70, 1)
    __show._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 117, 2)
    
    show = property(__show.value, __show.set, None, None)

    
    # Attribute {http://www.w3.org/1999/xlink}actuate uses Python identifier actuate
    __actuate = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(_Namespace, 'actuate'), 'actuate', '__httpwww_opengis_netcitygmlappearance1_0_TextureAssociationType_httpwww_w3_org1999xlinkactuate', pyxb.bundles.common.xlink.actuateType)
    __actuate._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 82, 1)
    __actuate._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/common/schemas/xlink.xsd', 118, 2)
    
    actuate = property(__actuate.value, __actuate.set, None, None)

    _ElementMap.update({
        __TextureParameterization.name() : __TextureParameterization
    })
    _AttributeMap.update({
        __uri.name() : __uri,
        __remoteSchema.name() : __remoteSchema,
        __type.name() : __type,
        __href.name() : __href,
        __role.name() : __role,
        __arcrole.name() : __arcrole,
        __title.name() : __title,
        __show.name() : __show,
        __actuate.name() : __actuate
    })
_module_typeBindings.TextureAssociationType = TextureAssociationType
Namespace.addCategoryObject('typeBinding', 'TextureAssociationType', TextureAssociationType)


# Complex type {http://www.opengis.net/citygml/appearance/1.0}AbstractTextureParameterizationType with content type ELEMENT_ONLY
class AbstractTextureParameterizationType (pyxb.bundles.opengis.gml.AbstractGMLType):
    """Base class for augmenting a link "texture->surface" with texture parameterization. Subclasses of
                this class define concrete parameterizations. Currently, texture coordinates and texture coordinate generation
                using a transformation matrix are available. """
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = True
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, 'AbstractTextureParameterizationType')
    _XSDLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 185, 4)
    _ElementMap = pyxb.bundles.opengis.gml.AbstractGMLType._ElementMap.copy()
    _AttributeMap = pyxb.bundles.opengis.gml.AbstractGMLType._AttributeMap.copy()
    # Base type is pyxb.bundles.opengis.gml.AbstractGMLType
    
    # Element {http://www.opengis.net/citygml/appearance/1.0}_GenericApplicationPropertyOfTextureParameterization uses Python identifier GenericApplicationPropertyOfTextureParameterization
    __GenericApplicationPropertyOfTextureParameterization = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfTextureParameterization'), 'GenericApplicationPropertyOfTextureParameterization', '__httpwww_opengis_netcitygmlappearance1_0_AbstractTextureParameterizationType_httpwww_opengis_netcitygmlappearance1_0_GenericApplicationPropertyOfTextureParameterization', True, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 203, 4), )

    
    GenericApplicationPropertyOfTextureParameterization = property(__GenericApplicationPropertyOfTextureParameterization.value, __GenericApplicationPropertyOfTextureParameterization.set, None, None)

    
    # Element metaDataProperty ({http://www.opengis.net/gml}metaDataProperty) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Element name ({http://www.opengis.net/gml}name) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Element description ({http://www.opengis.net/gml}description) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Attribute id inherited from {http://www.opengis.net/gml}AbstractGMLType
    _ElementMap.update({
        __GenericApplicationPropertyOfTextureParameterization.name() : __GenericApplicationPropertyOfTextureParameterization
    })
    _AttributeMap.update({
        
    })
_module_typeBindings.AbstractTextureParameterizationType = AbstractTextureParameterizationType
Namespace.addCategoryObject('typeBinding', 'AbstractTextureParameterizationType', AbstractTextureParameterizationType)


# Complex type [anonymous] with content type SIMPLE
class CTD_ANON (pyxb.binding.basis.complexTypeDefinition):
    """Complex type [anonymous] with content type SIMPLE"""
    _TypeDefinition = pyxb.bundles.opengis.gml.doubleList
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_SIMPLE
    _Abstract = False
    _ExpandedName = None
    _XSDLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 217, 24)
    _ElementMap = {}
    _AttributeMap = {}
    # Base type is pyxb.bundles.opengis.gml.doubleList
    
    # Attribute ring uses Python identifier ring
    __ring = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, 'ring'), 'ring', '__httpwww_opengis_netcitygmlappearance1_0_CTD_ANON_ring', pyxb.binding.datatypes.anyURI, required=True)
    __ring._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 220, 36)
    __ring._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 220, 36)
    
    ring = property(__ring.value, __ring.set, None, None)

    _ElementMap.update({
        
    })
    _AttributeMap.update({
        __ring.name() : __ring
    })
_module_typeBindings.CTD_ANON = CTD_ANON


# Complex type [anonymous] with content type SIMPLE
class CTD_ANON_ (pyxb.binding.basis.complexTypeDefinition):
    """Complex type [anonymous] with content type SIMPLE"""
    _TypeDefinition = pyxb.bundles.opengis.citygml.base.TransformationMatrix3x4Type
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_SIMPLE
    _Abstract = False
    _ExpandedName = None
    _XSDLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 248, 24)
    _ElementMap = {}
    _AttributeMap = {}
    # Base type is pyxb.bundles.opengis.citygml.base.TransformationMatrix3x4Type
    
    # Attribute srsName uses Python identifier srsName
    __srsName = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, 'srsName'), 'srsName', '__httpwww_opengis_netcitygmlappearance1_0_CTD_ANON__srsName', pyxb.binding.datatypes.anyURI)
    __srsName._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/geometryBasic0d1d.xsd', 113, 2)
    __srsName._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/geometryBasic0d1d.xsd', 113, 2)
    
    srsName = property(__srsName.value, __srsName.set, None, 'In general this reference points to a CRS instance of gml:CoordinateReferenceSystemType \n\t\t\t\t(see coordinateReferenceSystems.xsd). For well known references it is not required that the CRS description exists at the \n\t\t\t\tlocation the URI points to. If no srsName attribute is given, the CRS must be specified as part of the larger context this \n\t\t\t\tgeometry element is part of, e.g. a geometric element like point, curve, etc. It is expected that this attribute will be specified \n\t\t\t\tat the direct position level only in rare cases.')

    
    # Attribute srsDimension uses Python identifier srsDimension
    __srsDimension = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, 'srsDimension'), 'srsDimension', '__httpwww_opengis_netcitygmlappearance1_0_CTD_ANON__srsDimension', pyxb.binding.datatypes.positiveInteger)
    __srsDimension._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/geometryBasic0d1d.xsd', 122, 2)
    __srsDimension._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/geometryBasic0d1d.xsd', 122, 2)
    
    srsDimension = property(__srsDimension.value, __srsDimension.set, None, 'The "srsDimension" is the length of coordinate sequence (the number of entries in the list). This dimension is \n\t\t\t\tspecified by the coordinate reference system. When the srsName attribute is omitted, this attribute shall be omitted.')

    
    # Attribute axisLabels uses Python identifier axisLabels
    __axisLabels = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, 'axisLabels'), 'axisLabels', '__httpwww_opengis_netcitygmlappearance1_0_CTD_ANON__axisLabels', pyxb.bundles.opengis.gml.NCNameList)
    __axisLabels._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/geometryBasic0d1d.xsd', 138, 2)
    __axisLabels._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/geometryBasic0d1d.xsd', 138, 2)
    
    axisLabels = property(__axisLabels.value, __axisLabels.set, None, 'Ordered list of labels for all the axes of this CRS. The gml:axisAbbrev value should be used for these axis \n\t\t\t\tlabels, after spaces and forbiddden characters are removed. When the srsName attribute is included, this attribute is optional. \n\t\t\t\tWhen the srsName attribute is omitted, this attribute shall also be omitted.')

    
    # Attribute uomLabels uses Python identifier uomLabels
    __uomLabels = pyxb.binding.content.AttributeUse(pyxb.namespace.ExpandedName(None, 'uomLabels'), 'uomLabels', '__httpwww_opengis_netcitygmlappearance1_0_CTD_ANON__uomLabels', pyxb.bundles.opengis.gml.NCNameList)
    __uomLabels._DeclarationLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/geometryBasic0d1d.xsd', 145, 2)
    __uomLabels._UseLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/geometryBasic0d1d.xsd', 145, 2)
    
    uomLabels = property(__uomLabels.value, __uomLabels.set, None, 'Ordered list of unit of measure (uom) labels for all the axes of this CRS. The value of the string in the \n\t\t\t\tgml:catalogSymbol should be used for this uom labels, after spaces and forbiddden characters are removed. When the \n\t\t\t\taxisLabels attribute is included, this attribute shall also be included. When the axisLabels attribute is omitted, this attribute \n\t\t\t\tshall also be omitted.')

    _ElementMap.update({
        
    })
    _AttributeMap.update({
        __srsName.name() : __srsName,
        __srsDimension.name() : __srsDimension,
        __axisLabels.name() : __axisLabels,
        __uomLabels.name() : __uomLabels
    })
_module_typeBindings.CTD_ANON_ = CTD_ANON_


# Complex type {http://www.opengis.net/citygml/appearance/1.0}AbstractTextureType with content type ELEMENT_ONLY
class AbstractTextureType (AbstractSurfaceDataType):
    """Base class for textures. "imageURI" can contain any valid URI from references to a local file to
                preformatted web service requests. The linking to geometry and texture parameterization is provided by derived
                classes."""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, 'AbstractTextureType')
    _XSDLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 84, 4)
    _ElementMap = AbstractSurfaceDataType._ElementMap.copy()
    _AttributeMap = AbstractSurfaceDataType._AttributeMap.copy()
    # Base type is AbstractSurfaceDataType
    
    # Element isFront ({http://www.opengis.net/citygml/appearance/1.0}isFront) inherited from {http://www.opengis.net/citygml/appearance/1.0}AbstractSurfaceDataType
    
    # Element GenericApplicationPropertyOfSurfaceData ({http://www.opengis.net/citygml/appearance/1.0}_GenericApplicationPropertyOfSurfaceData) inherited from {http://www.opengis.net/citygml/appearance/1.0}AbstractSurfaceDataType
    
    # Element {http://www.opengis.net/citygml/appearance/1.0}imageURI uses Python identifier imageURI
    __imageURI = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'imageURI'), 'imageURI', '__httpwww_opengis_netcitygmlappearance1_0_AbstractTextureType_httpwww_opengis_netcitygmlappearance1_0imageURI', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 93, 20), )

    
    imageURI = property(__imageURI.value, __imageURI.set, None, None)

    
    # Element {http://www.opengis.net/citygml/appearance/1.0}mimeType uses Python identifier mimeType
    __mimeType = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'mimeType'), 'mimeType', '__httpwww_opengis_netcitygmlappearance1_0_AbstractTextureType_httpwww_opengis_netcitygmlappearance1_0mimeType', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 94, 20), )

    
    mimeType = property(__mimeType.value, __mimeType.set, None, None)

    
    # Element {http://www.opengis.net/citygml/appearance/1.0}textureType uses Python identifier textureType
    __textureType = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'textureType'), 'textureType', '__httpwww_opengis_netcitygmlappearance1_0_AbstractTextureType_httpwww_opengis_netcitygmlappearance1_0textureType', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 95, 20), )

    
    textureType = property(__textureType.value, __textureType.set, None, None)

    
    # Element {http://www.opengis.net/citygml/appearance/1.0}wrapMode uses Python identifier wrapMode
    __wrapMode = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'wrapMode'), 'wrapMode', '__httpwww_opengis_netcitygmlappearance1_0_AbstractTextureType_httpwww_opengis_netcitygmlappearance1_0wrapMode', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 96, 20), )

    
    wrapMode = property(__wrapMode.value, __wrapMode.set, None, None)

    
    # Element {http://www.opengis.net/citygml/appearance/1.0}borderColor uses Python identifier borderColor
    __borderColor = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'borderColor'), 'borderColor', '__httpwww_opengis_netcitygmlappearance1_0_AbstractTextureType_httpwww_opengis_netcitygmlappearance1_0borderColor', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 97, 20), )

    
    borderColor = property(__borderColor.value, __borderColor.set, None, None)

    
    # Element {http://www.opengis.net/citygml/appearance/1.0}_GenericApplicationPropertyOfTexture uses Python identifier GenericApplicationPropertyOfTexture
    __GenericApplicationPropertyOfTexture = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfTexture'), 'GenericApplicationPropertyOfTexture', '__httpwww_opengis_netcitygmlappearance1_0_AbstractTextureType_httpwww_opengis_netcitygmlappearance1_0_GenericApplicationPropertyOfTexture', True, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 106, 4), )

    
    GenericApplicationPropertyOfTexture = property(__GenericApplicationPropertyOfTexture.value, __GenericApplicationPropertyOfTexture.set, None, None)

    
    # Element boundedBy ({http://www.opengis.net/gml}boundedBy) inherited from {http://www.opengis.net/gml}AbstractFeatureType
    
    # Element location ({http://www.opengis.net/gml}location) inherited from {http://www.opengis.net/gml}AbstractFeatureType
    
    # Element metaDataProperty ({http://www.opengis.net/gml}metaDataProperty) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Element name ({http://www.opengis.net/gml}name) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Element description ({http://www.opengis.net/gml}description) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Attribute id inherited from {http://www.opengis.net/gml}AbstractGMLType
    _ElementMap.update({
        __imageURI.name() : __imageURI,
        __mimeType.name() : __mimeType,
        __textureType.name() : __textureType,
        __wrapMode.name() : __wrapMode,
        __borderColor.name() : __borderColor,
        __GenericApplicationPropertyOfTexture.name() : __GenericApplicationPropertyOfTexture
    })
    _AttributeMap.update({
        
    })
_module_typeBindings.AbstractTextureType = AbstractTextureType
Namespace.addCategoryObject('typeBinding', 'AbstractTextureType', AbstractTextureType)


# Complex type {http://www.opengis.net/citygml/appearance/1.0}TexCoordListType with content type ELEMENT_ONLY
class TexCoordListType (AbstractTextureParameterizationType):
    """Texture parameterization using texture coordinates: Each gml:LinearRing that is part of the surface
                requires a separate "textureCoordinates"-entry with 2 doubles per ring vertex. The "ring"- attribute provides the
                gml:id of the target LinearRing. It is prohibited to link texture coordinates to any other object type than
                LinearRing. Thus, surfaces not consisting of LinearRings cannot be textured this way. Use transformation matrices
                (see below) or georeferenced textures instead. """
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, 'TexCoordListType')
    _XSDLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 205, 4)
    _ElementMap = AbstractTextureParameterizationType._ElementMap.copy()
    _AttributeMap = AbstractTextureParameterizationType._AttributeMap.copy()
    # Base type is AbstractTextureParameterizationType
    
    # Element GenericApplicationPropertyOfTextureParameterization ({http://www.opengis.net/citygml/appearance/1.0}_GenericApplicationPropertyOfTextureParameterization) inherited from {http://www.opengis.net/citygml/appearance/1.0}AbstractTextureParameterizationType
    
    # Element {http://www.opengis.net/citygml/appearance/1.0}textureCoordinates uses Python identifier textureCoordinates
    __textureCoordinates = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'textureCoordinates'), 'textureCoordinates', '__httpwww_opengis_netcitygmlappearance1_0_TexCoordListType_httpwww_opengis_netcitygmlappearance1_0textureCoordinates', True, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 216, 20), )

    
    textureCoordinates = property(__textureCoordinates.value, __textureCoordinates.set, None, None)

    
    # Element {http://www.opengis.net/citygml/appearance/1.0}_GenericApplicationPropertyOfTexCoordList uses Python identifier GenericApplicationPropertyOfTexCoordList
    __GenericApplicationPropertyOfTexCoordList = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfTexCoordList'), 'GenericApplicationPropertyOfTexCoordList', '__httpwww_opengis_netcitygmlappearance1_0_TexCoordListType_httpwww_opengis_netcitygmlappearance1_0_GenericApplicationPropertyOfTexCoordList', True, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 233, 4), )

    
    GenericApplicationPropertyOfTexCoordList = property(__GenericApplicationPropertyOfTexCoordList.value, __GenericApplicationPropertyOfTexCoordList.set, None, None)

    
    # Element metaDataProperty ({http://www.opengis.net/gml}metaDataProperty) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Element name ({http://www.opengis.net/gml}name) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Element description ({http://www.opengis.net/gml}description) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Attribute id inherited from {http://www.opengis.net/gml}AbstractGMLType
    _ElementMap.update({
        __textureCoordinates.name() : __textureCoordinates,
        __GenericApplicationPropertyOfTexCoordList.name() : __GenericApplicationPropertyOfTexCoordList
    })
    _AttributeMap.update({
        
    })
_module_typeBindings.TexCoordListType = TexCoordListType
Namespace.addCategoryObject('typeBinding', 'TexCoordListType', TexCoordListType)


# Complex type {http://www.opengis.net/citygml/appearance/1.0}TexCoordGenType with content type ELEMENT_ONLY
class TexCoordGenType (AbstractTextureParameterizationType):
    """Texture parameterization using a transformation matrix. The transformation matrix "worldToTexture"
                can be used to derive texture coordinates from an object's location. This 3x4 matrix T computes the coordinates
                (s,t) from a homogeneous world position p as (s,t) = (s'/q', t'/q') with (s', t', q') = T*p. Thus, perspective
                projections can be specified. The SRS can be specified using standard attributes. If an object is given in a
                different reference system, it is transformed to the SRS before applying the transformation. A transformation
                matrix can be used for whole surfaces. It is not required to specify it per LinearRing. """
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, 'TexCoordGenType')
    _XSDLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 235, 4)
    _ElementMap = AbstractTextureParameterizationType._ElementMap.copy()
    _AttributeMap = AbstractTextureParameterizationType._AttributeMap.copy()
    # Base type is AbstractTextureParameterizationType
    
    # Element GenericApplicationPropertyOfTextureParameterization ({http://www.opengis.net/citygml/appearance/1.0}_GenericApplicationPropertyOfTextureParameterization) inherited from {http://www.opengis.net/citygml/appearance/1.0}AbstractTextureParameterizationType
    
    # Element {http://www.opengis.net/citygml/appearance/1.0}worldToTexture uses Python identifier worldToTexture
    __worldToTexture = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'worldToTexture'), 'worldToTexture', '__httpwww_opengis_netcitygmlappearance1_0_TexCoordGenType_httpwww_opengis_netcitygmlappearance1_0worldToTexture', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 247, 20), )

    
    worldToTexture = property(__worldToTexture.value, __worldToTexture.set, None, None)

    
    # Element {http://www.opengis.net/citygml/appearance/1.0}_GenericApplicationPropertyOfTexCoordGen uses Python identifier GenericApplicationPropertyOfTexCoordGen
    __GenericApplicationPropertyOfTexCoordGen = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfTexCoordGen'), 'GenericApplicationPropertyOfTexCoordGen', '__httpwww_opengis_netcitygmlappearance1_0_TexCoordGenType_httpwww_opengis_netcitygmlappearance1_0_GenericApplicationPropertyOfTexCoordGen', True, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 264, 4), )

    
    GenericApplicationPropertyOfTexCoordGen = property(__GenericApplicationPropertyOfTexCoordGen.value, __GenericApplicationPropertyOfTexCoordGen.set, None, None)

    
    # Element metaDataProperty ({http://www.opengis.net/gml}metaDataProperty) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Element name ({http://www.opengis.net/gml}name) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Element description ({http://www.opengis.net/gml}description) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Attribute id inherited from {http://www.opengis.net/gml}AbstractGMLType
    _ElementMap.update({
        __worldToTexture.name() : __worldToTexture,
        __GenericApplicationPropertyOfTexCoordGen.name() : __GenericApplicationPropertyOfTexCoordGen
    })
    _AttributeMap.update({
        
    })
_module_typeBindings.TexCoordGenType = TexCoordGenType
Namespace.addCategoryObject('typeBinding', 'TexCoordGenType', TexCoordGenType)


# Complex type {http://www.opengis.net/citygml/appearance/1.0}X3DMaterialType with content type ELEMENT_ONLY
class X3DMaterialType (AbstractSurfaceDataType):
    """Class for defining constant surface properties. It is based on X3D's material definition. In
                addition, "isSmooth" provides a hint for value interpolation. The link to surface geometry is established via the
                "target"-property. Only gml:MultiSurface or decendants of gml:AbstractSurfaceType are valid targets.
            """
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, 'X3DMaterialType')
    _XSDLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 266, 4)
    _ElementMap = AbstractSurfaceDataType._ElementMap.copy()
    _AttributeMap = AbstractSurfaceDataType._AttributeMap.copy()
    # Base type is AbstractSurfaceDataType
    
    # Element isFront ({http://www.opengis.net/citygml/appearance/1.0}isFront) inherited from {http://www.opengis.net/citygml/appearance/1.0}AbstractSurfaceDataType
    
    # Element GenericApplicationPropertyOfSurfaceData ({http://www.opengis.net/citygml/appearance/1.0}_GenericApplicationPropertyOfSurfaceData) inherited from {http://www.opengis.net/citygml/appearance/1.0}AbstractSurfaceDataType
    
    # Element {http://www.opengis.net/citygml/appearance/1.0}ambientIntensity uses Python identifier ambientIntensity
    __ambientIntensity = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'ambientIntensity'), 'ambientIntensity', '__httpwww_opengis_netcitygmlappearance1_0_X3DMaterialType_httpwww_opengis_netcitygmlappearance1_0ambientIntensity', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 276, 20), )

    
    ambientIntensity = property(__ambientIntensity.value, __ambientIntensity.set, None, None)

    
    # Element {http://www.opengis.net/citygml/appearance/1.0}diffuseColor uses Python identifier diffuseColor
    __diffuseColor = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'diffuseColor'), 'diffuseColor', '__httpwww_opengis_netcitygmlappearance1_0_X3DMaterialType_httpwww_opengis_netcitygmlappearance1_0diffuseColor', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 277, 20), )

    
    diffuseColor = property(__diffuseColor.value, __diffuseColor.set, None, None)

    
    # Element {http://www.opengis.net/citygml/appearance/1.0}emissiveColor uses Python identifier emissiveColor
    __emissiveColor = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'emissiveColor'), 'emissiveColor', '__httpwww_opengis_netcitygmlappearance1_0_X3DMaterialType_httpwww_opengis_netcitygmlappearance1_0emissiveColor', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 278, 20), )

    
    emissiveColor = property(__emissiveColor.value, __emissiveColor.set, None, None)

    
    # Element {http://www.opengis.net/citygml/appearance/1.0}specularColor uses Python identifier specularColor
    __specularColor = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'specularColor'), 'specularColor', '__httpwww_opengis_netcitygmlappearance1_0_X3DMaterialType_httpwww_opengis_netcitygmlappearance1_0specularColor', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 279, 20), )

    
    specularColor = property(__specularColor.value, __specularColor.set, None, None)

    
    # Element {http://www.opengis.net/citygml/appearance/1.0}shininess uses Python identifier shininess
    __shininess = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'shininess'), 'shininess', '__httpwww_opengis_netcitygmlappearance1_0_X3DMaterialType_httpwww_opengis_netcitygmlappearance1_0shininess', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 280, 20), )

    
    shininess = property(__shininess.value, __shininess.set, None, None)

    
    # Element {http://www.opengis.net/citygml/appearance/1.0}transparency uses Python identifier transparency
    __transparency = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'transparency'), 'transparency', '__httpwww_opengis_netcitygmlappearance1_0_X3DMaterialType_httpwww_opengis_netcitygmlappearance1_0transparency', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 281, 20), )

    
    transparency = property(__transparency.value, __transparency.set, None, None)

    
    # Element {http://www.opengis.net/citygml/appearance/1.0}isSmooth uses Python identifier isSmooth
    __isSmooth = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'isSmooth'), 'isSmooth', '__httpwww_opengis_netcitygmlappearance1_0_X3DMaterialType_httpwww_opengis_netcitygmlappearance1_0isSmooth', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 282, 20), )

    
    isSmooth = property(__isSmooth.value, __isSmooth.set, None, None)

    
    # Element {http://www.opengis.net/citygml/appearance/1.0}target uses Python identifier target
    __target = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'target'), 'target', '__httpwww_opengis_netcitygmlappearance1_0_X3DMaterialType_httpwww_opengis_netcitygmlappearance1_0target', True, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 283, 20), )

    
    target = property(__target.value, __target.set, None, None)

    
    # Element {http://www.opengis.net/citygml/appearance/1.0}_GenericApplicationPropertyOfX3DMaterial uses Python identifier GenericApplicationPropertyOfX3DMaterial
    __GenericApplicationPropertyOfX3DMaterial = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfX3DMaterial'), 'GenericApplicationPropertyOfX3DMaterial', '__httpwww_opengis_netcitygmlappearance1_0_X3DMaterialType_httpwww_opengis_netcitygmlappearance1_0_GenericApplicationPropertyOfX3DMaterial', True, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 292, 4), )

    
    GenericApplicationPropertyOfX3DMaterial = property(__GenericApplicationPropertyOfX3DMaterial.value, __GenericApplicationPropertyOfX3DMaterial.set, None, None)

    
    # Element boundedBy ({http://www.opengis.net/gml}boundedBy) inherited from {http://www.opengis.net/gml}AbstractFeatureType
    
    # Element location ({http://www.opengis.net/gml}location) inherited from {http://www.opengis.net/gml}AbstractFeatureType
    
    # Element metaDataProperty ({http://www.opengis.net/gml}metaDataProperty) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Element name ({http://www.opengis.net/gml}name) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Element description ({http://www.opengis.net/gml}description) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Attribute id inherited from {http://www.opengis.net/gml}AbstractGMLType
    _ElementMap.update({
        __ambientIntensity.name() : __ambientIntensity,
        __diffuseColor.name() : __diffuseColor,
        __emissiveColor.name() : __emissiveColor,
        __specularColor.name() : __specularColor,
        __shininess.name() : __shininess,
        __transparency.name() : __transparency,
        __isSmooth.name() : __isSmooth,
        __target.name() : __target,
        __GenericApplicationPropertyOfX3DMaterial.name() : __GenericApplicationPropertyOfX3DMaterial
    })
    _AttributeMap.update({
        
    })
_module_typeBindings.X3DMaterialType = X3DMaterialType
Namespace.addCategoryObject('typeBinding', 'X3DMaterialType', X3DMaterialType)


# Complex type {http://www.opengis.net/citygml/appearance/1.0}ParameterizedTextureType with content type ELEMENT_ONLY
class ParameterizedTextureType (AbstractTextureType):
    """Specialization for standard 2D textures. "target" provides the linking to surface geometry. Only
                gml:MultiSurface and decendants of gml:AbstractSurfaceType are valid targets. As property of the link, a texture
                parameterization either as set of texture coordinates or transformation matrix is given. """
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, 'ParameterizedTextureType')
    _XSDLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 122, 4)
    _ElementMap = AbstractTextureType._ElementMap.copy()
    _AttributeMap = AbstractTextureType._AttributeMap.copy()
    # Base type is AbstractTextureType
    
    # Element isFront ({http://www.opengis.net/citygml/appearance/1.0}isFront) inherited from {http://www.opengis.net/citygml/appearance/1.0}AbstractSurfaceDataType
    
    # Element GenericApplicationPropertyOfSurfaceData ({http://www.opengis.net/citygml/appearance/1.0}_GenericApplicationPropertyOfSurfaceData) inherited from {http://www.opengis.net/citygml/appearance/1.0}AbstractSurfaceDataType
    
    # Element imageURI ({http://www.opengis.net/citygml/appearance/1.0}imageURI) inherited from {http://www.opengis.net/citygml/appearance/1.0}AbstractTextureType
    
    # Element mimeType ({http://www.opengis.net/citygml/appearance/1.0}mimeType) inherited from {http://www.opengis.net/citygml/appearance/1.0}AbstractTextureType
    
    # Element textureType ({http://www.opengis.net/citygml/appearance/1.0}textureType) inherited from {http://www.opengis.net/citygml/appearance/1.0}AbstractTextureType
    
    # Element wrapMode ({http://www.opengis.net/citygml/appearance/1.0}wrapMode) inherited from {http://www.opengis.net/citygml/appearance/1.0}AbstractTextureType
    
    # Element borderColor ({http://www.opengis.net/citygml/appearance/1.0}borderColor) inherited from {http://www.opengis.net/citygml/appearance/1.0}AbstractTextureType
    
    # Element GenericApplicationPropertyOfTexture ({http://www.opengis.net/citygml/appearance/1.0}_GenericApplicationPropertyOfTexture) inherited from {http://www.opengis.net/citygml/appearance/1.0}AbstractTextureType
    
    # Element {http://www.opengis.net/citygml/appearance/1.0}target uses Python identifier target
    __target = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'target'), 'target', '__httpwww_opengis_netcitygmlappearance1_0_ParameterizedTextureType_httpwww_opengis_netcitygmlappearance1_0target', True, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 131, 20), )

    
    target = property(__target.value, __target.set, None, None)

    
    # Element {http://www.opengis.net/citygml/appearance/1.0}_GenericApplicationPropertyOfParameterizedTexture uses Python identifier GenericApplicationPropertyOfParameterizedTexture
    __GenericApplicationPropertyOfParameterizedTexture = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfParameterizedTexture'), 'GenericApplicationPropertyOfParameterizedTexture', '__httpwww_opengis_netcitygmlappearance1_0_ParameterizedTextureType_httpwww_opengis_netcitygmlappearance1_0_GenericApplicationPropertyOfParameterizedTexture', True, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 140, 4), )

    
    GenericApplicationPropertyOfParameterizedTexture = property(__GenericApplicationPropertyOfParameterizedTexture.value, __GenericApplicationPropertyOfParameterizedTexture.set, None, None)

    
    # Element boundedBy ({http://www.opengis.net/gml}boundedBy) inherited from {http://www.opengis.net/gml}AbstractFeatureType
    
    # Element location ({http://www.opengis.net/gml}location) inherited from {http://www.opengis.net/gml}AbstractFeatureType
    
    # Element metaDataProperty ({http://www.opengis.net/gml}metaDataProperty) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Element name ({http://www.opengis.net/gml}name) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Element description ({http://www.opengis.net/gml}description) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Attribute id inherited from {http://www.opengis.net/gml}AbstractGMLType
    _ElementMap.update({
        __target.name() : __target,
        __GenericApplicationPropertyOfParameterizedTexture.name() : __GenericApplicationPropertyOfParameterizedTexture
    })
    _AttributeMap.update({
        
    })
_module_typeBindings.ParameterizedTextureType = ParameterizedTextureType
Namespace.addCategoryObject('typeBinding', 'ParameterizedTextureType', ParameterizedTextureType)


# Complex type {http://www.opengis.net/citygml/appearance/1.0}GeoreferencedTextureType with content type ELEMENT_ONLY
class GeoreferencedTextureType (AbstractTextureType):
    """Specialization for georeferenced textures, i.e. textures using a planimetric projection. Such
                textures contain an implicit parameterization (either stored within the image file, in an acompanying world file,
                or using the "referencePoint" and "orientation"-elements). A georeference provided by "referencePoint" and
                "orientation" always takes precedence. The search order for an external georeference is determined by the boolean
                flag preferWorldFile. If this flag is set to true (its default value), a world file is looked for first and only
                if it is not found the georeference from the image data is used. If preferWorldFile is false, the world file is
                used only if no georeference from the image data is available. The "boundedBy"-property should contain the
                bounding box of the projected image data. Since a georeferenced texture has a unique parameterization, "target"
                only provides links to surface geometry without any additional texture parameterization. Only gml:MultiSurface or
                decendants of gml:AbstractSurfaceType are valid targets."""
    _TypeDefinition = None
    _ContentTypeTag = pyxb.binding.basis.complexTypeDefinition._CT_ELEMENT_ONLY
    _Abstract = False
    _ExpandedName = pyxb.namespace.ExpandedName(Namespace, 'GeoreferencedTextureType')
    _XSDLocation = pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 142, 4)
    _ElementMap = AbstractTextureType._ElementMap.copy()
    _AttributeMap = AbstractTextureType._AttributeMap.copy()
    # Base type is AbstractTextureType
    
    # Element isFront ({http://www.opengis.net/citygml/appearance/1.0}isFront) inherited from {http://www.opengis.net/citygml/appearance/1.0}AbstractSurfaceDataType
    
    # Element GenericApplicationPropertyOfSurfaceData ({http://www.opengis.net/citygml/appearance/1.0}_GenericApplicationPropertyOfSurfaceData) inherited from {http://www.opengis.net/citygml/appearance/1.0}AbstractSurfaceDataType
    
    # Element imageURI ({http://www.opengis.net/citygml/appearance/1.0}imageURI) inherited from {http://www.opengis.net/citygml/appearance/1.0}AbstractTextureType
    
    # Element mimeType ({http://www.opengis.net/citygml/appearance/1.0}mimeType) inherited from {http://www.opengis.net/citygml/appearance/1.0}AbstractTextureType
    
    # Element textureType ({http://www.opengis.net/citygml/appearance/1.0}textureType) inherited from {http://www.opengis.net/citygml/appearance/1.0}AbstractTextureType
    
    # Element wrapMode ({http://www.opengis.net/citygml/appearance/1.0}wrapMode) inherited from {http://www.opengis.net/citygml/appearance/1.0}AbstractTextureType
    
    # Element borderColor ({http://www.opengis.net/citygml/appearance/1.0}borderColor) inherited from {http://www.opengis.net/citygml/appearance/1.0}AbstractTextureType
    
    # Element GenericApplicationPropertyOfTexture ({http://www.opengis.net/citygml/appearance/1.0}_GenericApplicationPropertyOfTexture) inherited from {http://www.opengis.net/citygml/appearance/1.0}AbstractTextureType
    
    # Element {http://www.opengis.net/citygml/appearance/1.0}preferWorldFile uses Python identifier preferWorldFile
    __preferWorldFile = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'preferWorldFile'), 'preferWorldFile', '__httpwww_opengis_netcitygmlappearance1_0_GeoreferencedTextureType_httpwww_opengis_netcitygmlappearance1_0preferWorldFile', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 158, 20), )

    
    preferWorldFile = property(__preferWorldFile.value, __preferWorldFile.set, None, None)

    
    # Element {http://www.opengis.net/citygml/appearance/1.0}referencePoint uses Python identifier referencePoint
    __referencePoint = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'referencePoint'), 'referencePoint', '__httpwww_opengis_netcitygmlappearance1_0_GeoreferencedTextureType_httpwww_opengis_netcitygmlappearance1_0referencePoint', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 159, 20), )

    
    referencePoint = property(__referencePoint.value, __referencePoint.set, None, None)

    
    # Element {http://www.opengis.net/citygml/appearance/1.0}orientation uses Python identifier orientation
    __orientation = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'orientation'), 'orientation', '__httpwww_opengis_netcitygmlappearance1_0_GeoreferencedTextureType_httpwww_opengis_netcitygmlappearance1_0orientation', False, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 160, 20), )

    
    orientation = property(__orientation.value, __orientation.set, None, None)

    
    # Element {http://www.opengis.net/citygml/appearance/1.0}target uses Python identifier target
    __target = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, 'target'), 'target', '__httpwww_opengis_netcitygmlappearance1_0_GeoreferencedTextureType_httpwww_opengis_netcitygmlappearance1_0target', True, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 161, 20), )

    
    target = property(__target.value, __target.set, None, None)

    
    # Element {http://www.opengis.net/citygml/appearance/1.0}_GenericApplicationPropertyOfGeoreferencedTexture uses Python identifier GenericApplicationPropertyOfGeoreferencedTexture
    __GenericApplicationPropertyOfGeoreferencedTexture = pyxb.binding.content.ElementDeclaration(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfGeoreferencedTexture'), 'GenericApplicationPropertyOfGeoreferencedTexture', '__httpwww_opengis_netcitygmlappearance1_0_GeoreferencedTextureType_httpwww_opengis_netcitygmlappearance1_0_GenericApplicationPropertyOfGeoreferencedTexture', True, pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 170, 4), )

    
    GenericApplicationPropertyOfGeoreferencedTexture = property(__GenericApplicationPropertyOfGeoreferencedTexture.value, __GenericApplicationPropertyOfGeoreferencedTexture.set, None, None)

    
    # Element boundedBy ({http://www.opengis.net/gml}boundedBy) inherited from {http://www.opengis.net/gml}AbstractFeatureType
    
    # Element location ({http://www.opengis.net/gml}location) inherited from {http://www.opengis.net/gml}AbstractFeatureType
    
    # Element metaDataProperty ({http://www.opengis.net/gml}metaDataProperty) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Element name ({http://www.opengis.net/gml}name) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Element description ({http://www.opengis.net/gml}description) inherited from {http://www.opengis.net/gml}AbstractGMLType
    
    # Attribute id inherited from {http://www.opengis.net/gml}AbstractGMLType
    _ElementMap.update({
        __preferWorldFile.name() : __preferWorldFile,
        __referencePoint.name() : __referencePoint,
        __orientation.name() : __orientation,
        __target.name() : __target,
        __GenericApplicationPropertyOfGeoreferencedTexture.name() : __GenericApplicationPropertyOfGeoreferencedTexture
    })
    _AttributeMap.update({
        
    })
_module_typeBindings.GeoreferencedTextureType = GeoreferencedTextureType
Namespace.addCategoryObject('typeBinding', 'GeoreferencedTextureType', GeoreferencedTextureType)


GenericApplicationPropertyOfAppearance = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfAppearance'), pyxb.binding.datatypes.anyType, abstract=pyxb.binding.datatypes.boolean(1), location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 33, 4))
Namespace.addCategoryObject('elementBinding', GenericApplicationPropertyOfAppearance.name().localName(), GenericApplicationPropertyOfAppearance)

GenericApplicationPropertyOfSurfaceData = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfSurfaceData'), pyxb.binding.datatypes.anyType, abstract=pyxb.binding.datatypes.boolean(1), location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 70, 4))
Namespace.addCategoryObject('elementBinding', GenericApplicationPropertyOfSurfaceData.name().localName(), GenericApplicationPropertyOfSurfaceData)

GenericApplicationPropertyOfTexture = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfTexture'), pyxb.binding.datatypes.anyType, abstract=pyxb.binding.datatypes.boolean(1), location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 106, 4))
Namespace.addCategoryObject('elementBinding', GenericApplicationPropertyOfTexture.name().localName(), GenericApplicationPropertyOfTexture)

GenericApplicationPropertyOfParameterizedTexture = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfParameterizedTexture'), pyxb.binding.datatypes.anyType, abstract=pyxb.binding.datatypes.boolean(1), location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 140, 4))
Namespace.addCategoryObject('elementBinding', GenericApplicationPropertyOfParameterizedTexture.name().localName(), GenericApplicationPropertyOfParameterizedTexture)

GenericApplicationPropertyOfGeoreferencedTexture = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfGeoreferencedTexture'), pyxb.binding.datatypes.anyType, abstract=pyxb.binding.datatypes.boolean(1), location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 170, 4))
Namespace.addCategoryObject('elementBinding', GenericApplicationPropertyOfGeoreferencedTexture.name().localName(), GenericApplicationPropertyOfGeoreferencedTexture)

GenericApplicationPropertyOfTextureParameterization = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfTextureParameterization'), pyxb.binding.datatypes.anyType, abstract=pyxb.binding.datatypes.boolean(1), location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 203, 4))
Namespace.addCategoryObject('elementBinding', GenericApplicationPropertyOfTextureParameterization.name().localName(), GenericApplicationPropertyOfTextureParameterization)

GenericApplicationPropertyOfTexCoordList = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfTexCoordList'), pyxb.binding.datatypes.anyType, abstract=pyxb.binding.datatypes.boolean(1), location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 233, 4))
Namespace.addCategoryObject('elementBinding', GenericApplicationPropertyOfTexCoordList.name().localName(), GenericApplicationPropertyOfTexCoordList)

GenericApplicationPropertyOfTexCoordGen = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfTexCoordGen'), pyxb.binding.datatypes.anyType, abstract=pyxb.binding.datatypes.boolean(1), location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 264, 4))
Namespace.addCategoryObject('elementBinding', GenericApplicationPropertyOfTexCoordGen.name().localName(), GenericApplicationPropertyOfTexCoordGen)

GenericApplicationPropertyOfX3DMaterial = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfX3DMaterial'), pyxb.binding.datatypes.anyType, abstract=pyxb.binding.datatypes.boolean(1), location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 292, 4))
Namespace.addCategoryObject('elementBinding', GenericApplicationPropertyOfX3DMaterial.name().localName(), GenericApplicationPropertyOfX3DMaterial)

appearanceMember = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'appearanceMember'), AppearancePropertyType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 50, 4))
Namespace.addCategoryObject('elementBinding', appearanceMember.name().localName(), appearanceMember)

appearance = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'appearance'), AppearancePropertyType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 52, 4))
Namespace.addCategoryObject('elementBinding', appearance.name().localName(), appearance)

SurfaceData = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, '_SurfaceData'), AbstractSurfaceDataType, abstract=pyxb.binding.datatypes.boolean(1), location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 68, 4))
Namespace.addCategoryObject('elementBinding', SurfaceData.name().localName(), SurfaceData)

TextureParameterization = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, '_TextureParameterization'), AbstractTextureParameterizationType, abstract=pyxb.binding.datatypes.boolean(1), location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 200, 4))
Namespace.addCategoryObject('elementBinding', TextureParameterization.name().localName(), TextureParameterization)

Texture = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, '_Texture'), AbstractTextureType, abstract=pyxb.binding.datatypes.boolean(1), location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 104, 4))
Namespace.addCategoryObject('elementBinding', Texture.name().localName(), Texture)

TexCoordList = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'TexCoordList'), TexCoordListType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 231, 4))
Namespace.addCategoryObject('elementBinding', TexCoordList.name().localName(), TexCoordList)

TexCoordGen = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'TexCoordGen'), TexCoordGenType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 262, 4))
Namespace.addCategoryObject('elementBinding', TexCoordGen.name().localName(), TexCoordGen)

X3DMaterial = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'X3DMaterial'), X3DMaterialType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 290, 4))
Namespace.addCategoryObject('elementBinding', X3DMaterial.name().localName(), X3DMaterial)

ParameterizedTexture = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'ParameterizedTexture'), ParameterizedTextureType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 138, 4))
Namespace.addCategoryObject('elementBinding', ParameterizedTexture.name().localName(), ParameterizedTexture)

GeoreferencedTexture = pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'GeoreferencedTexture'), GeoreferencedTextureType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 168, 4))
Namespace.addCategoryObject('elementBinding', GeoreferencedTexture.name().localName(), GeoreferencedTexture)



AppearanceType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'theme'), pyxb.binding.datatypes.string, scope=AppearanceType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 25, 20)))

AppearanceType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'surfaceDataMember'), SurfaceDataPropertyType, scope=AppearanceType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 26, 20)))

AppearanceType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfAppearance'), pyxb.binding.datatypes.anyType, abstract=pyxb.binding.datatypes.boolean(1), scope=AppearanceType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 33, 4)))

def _BuildAutomaton ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton
    del _BuildAutomaton
    import pyxb.utils.fac as fac

    counters = set()
    cc_0 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 55, 3))
    counters.add(cc_0)
    cc_1 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 56, 3))
    counters.add(cc_1)
    cc_2 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 57, 3))
    counters.add(cc_2)
    cc_3 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 28, 5))
    counters.add(cc_3)
    cc_4 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 29, 5))
    counters.add(cc_4)
    cc_5 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 25, 20))
    counters.add(cc_5)
    cc_6 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 26, 20))
    counters.add(cc_6)
    cc_7 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 27, 20))
    counters.add(cc_7)
    states = []
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_0, False))
    symbol = pyxb.binding.content.ElementUse(AppearanceType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'metaDataProperty')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 55, 3))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_1, False))
    symbol = pyxb.binding.content.ElementUse(AppearanceType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'description')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 56, 3))
    st_1 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_1)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_2, False))
    symbol = pyxb.binding.content.ElementUse(AppearanceType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'name')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 57, 3))
    st_2 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_2)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_3, False))
    symbol = pyxb.binding.content.ElementUse(AppearanceType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'boundedBy')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 28, 5))
    st_3 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_3)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_4, False))
    symbol = pyxb.binding.content.ElementUse(AppearanceType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'location')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 29, 5))
    st_4 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_4)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_5, False))
    symbol = pyxb.binding.content.ElementUse(AppearanceType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'theme')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 25, 20))
    st_5 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_5)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_6, False))
    symbol = pyxb.binding.content.ElementUse(AppearanceType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'surfaceDataMember')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 26, 20))
    st_6 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_6)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_7, False))
    symbol = pyxb.binding.content.ElementUse(AppearanceType._UseForTag(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfAppearance')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 27, 20))
    st_7 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_7)
    transitions = []
    transitions.append(fac.Transition(st_0, [
        fac.UpdateInstruction(cc_0, True) ]))
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_0, False) ]))
    st_0._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_1, True) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_1, False) ]))
    st_1._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_2, True) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_2, False) ]))
    st_2._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_3, True) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_3, False) ]))
    st_3._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_4, True) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_4, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_4, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_4, False) ]))
    st_4._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_5, True) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_5, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_5, False) ]))
    st_5._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_6, True) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_6, False) ]))
    st_6._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_7, True) ]))
    st_7._set_transitionSet(transitions)
    return fac.Automaton(states, counters, True, containing_state=None)
AppearanceType._Automaton = _BuildAutomaton()




AppearancePropertyType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'Appearance'), AppearanceType, scope=AppearancePropertyType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 44, 20)))

def _BuildAutomaton_ ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton_
    del _BuildAutomaton_
    import pyxb.utils.fac as fac

    counters = set()
    cc_0 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 80, 2))
    counters.add(cc_0)
    cc_1 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 43, 16))
    counters.add(cc_1)
    states = []
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_0, False))
    symbol = pyxb.binding.content.ElementUse(AppearancePropertyType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, '_Feature')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 81, 3))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_1, False))
    symbol = pyxb.binding.content.ElementUse(AppearancePropertyType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'Appearance')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 44, 20))
    st_1 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_1)
    transitions = []
    transitions.append(fac.Transition(st_0, [
        fac.UpdateInstruction(cc_0, True) ]))
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_0, False) ]))
    st_0._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_1, True) ]))
    st_1._set_transitionSet(transitions)
    return fac.Automaton(states, counters, True, containing_state=None)
AppearancePropertyType._Automaton = _BuildAutomaton_()




AbstractSurfaceDataType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'isFront'), pyxb.binding.datatypes.boolean, scope=AbstractSurfaceDataType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 61, 20), unicode_default='true'))

AbstractSurfaceDataType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfSurfaceData'), pyxb.binding.datatypes.anyType, abstract=pyxb.binding.datatypes.boolean(1), scope=AbstractSurfaceDataType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 70, 4)))

def _BuildAutomaton_2 ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton_2
    del _BuildAutomaton_2
    import pyxb.utils.fac as fac

    counters = set()
    cc_0 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 55, 3))
    counters.add(cc_0)
    cc_1 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 56, 3))
    counters.add(cc_1)
    cc_2 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 57, 3))
    counters.add(cc_2)
    cc_3 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 28, 5))
    counters.add(cc_3)
    cc_4 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 29, 5))
    counters.add(cc_4)
    cc_5 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 61, 20))
    counters.add(cc_5)
    cc_6 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 62, 20))
    counters.add(cc_6)
    states = []
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_0, False))
    symbol = pyxb.binding.content.ElementUse(AbstractSurfaceDataType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'metaDataProperty')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 55, 3))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_1, False))
    symbol = pyxb.binding.content.ElementUse(AbstractSurfaceDataType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'description')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 56, 3))
    st_1 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_1)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_2, False))
    symbol = pyxb.binding.content.ElementUse(AbstractSurfaceDataType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'name')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 57, 3))
    st_2 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_2)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_3, False))
    symbol = pyxb.binding.content.ElementUse(AbstractSurfaceDataType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'boundedBy')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 28, 5))
    st_3 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_3)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_4, False))
    symbol = pyxb.binding.content.ElementUse(AbstractSurfaceDataType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'location')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 29, 5))
    st_4 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_4)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_5, False))
    symbol = pyxb.binding.content.ElementUse(AbstractSurfaceDataType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'isFront')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 61, 20))
    st_5 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_5)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_6, False))
    symbol = pyxb.binding.content.ElementUse(AbstractSurfaceDataType._UseForTag(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfSurfaceData')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 62, 20))
    st_6 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_6)
    transitions = []
    transitions.append(fac.Transition(st_0, [
        fac.UpdateInstruction(cc_0, True) ]))
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_0, False) ]))
    st_0._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_1, True) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_1, False) ]))
    st_1._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_2, True) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_2, False) ]))
    st_2._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_3, True) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_3, False) ]))
    st_3._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_4, True) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_4, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_4, False) ]))
    st_4._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_5, True) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_5, False) ]))
    st_5._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_6, True) ]))
    st_6._set_transitionSet(transitions)
    return fac.Automaton(states, counters, True, containing_state=None)
AbstractSurfaceDataType._Automaton = _BuildAutomaton_2()




SurfaceDataPropertyType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, '_SurfaceData'), AbstractSurfaceDataType, abstract=pyxb.binding.datatypes.boolean(1), scope=SurfaceDataPropertyType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 68, 4)))

def _BuildAutomaton_3 ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton_3
    del _BuildAutomaton_3
    import pyxb.utils.fac as fac

    counters = set()
    cc_0 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 78, 8))
    counters.add(cc_0)
    cc_1 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 79, 12))
    counters.add(cc_1)
    states = []
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_0, False))
    final_update.add(fac.UpdateInstruction(cc_1, False))
    symbol = pyxb.binding.content.ElementUse(SurfaceDataPropertyType._UseForTag(pyxb.namespace.ExpandedName(Namespace, '_SurfaceData')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 79, 12))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    transitions = []
    transitions.append(fac.Transition(st_0, [
        fac.UpdateInstruction(cc_0, True),
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_0, [
        fac.UpdateInstruction(cc_1, True) ]))
    st_0._set_transitionSet(transitions)
    return fac.Automaton(states, counters, True, containing_state=None)
SurfaceDataPropertyType._Automaton = _BuildAutomaton_3()




TextureAssociationType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, '_TextureParameterization'), AbstractTextureParameterizationType, abstract=pyxb.binding.datatypes.boolean(1), scope=TextureAssociationType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 200, 4)))

def _BuildAutomaton_4 ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton_4
    del _BuildAutomaton_4
    import pyxb.utils.fac as fac

    counters = set()
    cc_0 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 178, 8))
    counters.add(cc_0)
    states = []
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_0, False))
    symbol = pyxb.binding.content.ElementUse(TextureAssociationType._UseForTag(pyxb.namespace.ExpandedName(Namespace, '_TextureParameterization')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 179, 12))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    transitions = []
    transitions.append(fac.Transition(st_0, [
        fac.UpdateInstruction(cc_0, True) ]))
    st_0._set_transitionSet(transitions)
    return fac.Automaton(states, counters, True, containing_state=None)
TextureAssociationType._Automaton = _BuildAutomaton_4()




AbstractTextureParameterizationType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfTextureParameterization'), pyxb.binding.datatypes.anyType, abstract=pyxb.binding.datatypes.boolean(1), scope=AbstractTextureParameterizationType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 203, 4)))

def _BuildAutomaton_5 ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton_5
    del _BuildAutomaton_5
    import pyxb.utils.fac as fac

    counters = set()
    cc_0 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 55, 3))
    counters.add(cc_0)
    cc_1 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 56, 3))
    counters.add(cc_1)
    cc_2 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 57, 3))
    counters.add(cc_2)
    cc_3 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 194, 20))
    counters.add(cc_3)
    states = []
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_0, False))
    symbol = pyxb.binding.content.ElementUse(AbstractTextureParameterizationType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'metaDataProperty')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 55, 3))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_1, False))
    symbol = pyxb.binding.content.ElementUse(AbstractTextureParameterizationType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'description')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 56, 3))
    st_1 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_1)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_2, False))
    symbol = pyxb.binding.content.ElementUse(AbstractTextureParameterizationType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'name')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 57, 3))
    st_2 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_2)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_3, False))
    symbol = pyxb.binding.content.ElementUse(AbstractTextureParameterizationType._UseForTag(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfTextureParameterization')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 194, 20))
    st_3 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_3)
    transitions = []
    transitions.append(fac.Transition(st_0, [
        fac.UpdateInstruction(cc_0, True) ]))
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_0, False) ]))
    st_0._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_1, True) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_1, False) ]))
    st_1._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_2, True) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_2, False) ]))
    st_2._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_3, True) ]))
    st_3._set_transitionSet(transitions)
    return fac.Automaton(states, counters, True, containing_state=None)
AbstractTextureParameterizationType._Automaton = _BuildAutomaton_5()




AbstractTextureType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'imageURI'), pyxb.binding.datatypes.anyURI, scope=AbstractTextureType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 93, 20)))

AbstractTextureType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'mimeType'), pyxb.bundles.opengis.citygml.base.MimeTypeType, scope=AbstractTextureType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 94, 20)))

AbstractTextureType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'textureType'), TextureTypeType, scope=AbstractTextureType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 95, 20)))

AbstractTextureType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'wrapMode'), WrapModeType, scope=AbstractTextureType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 96, 20)))

AbstractTextureType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'borderColor'), ColorPlusOpacity, scope=AbstractTextureType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 97, 20)))

AbstractTextureType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfTexture'), pyxb.binding.datatypes.anyType, abstract=pyxb.binding.datatypes.boolean(1), scope=AbstractTextureType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 106, 4)))

def _BuildAutomaton_6 ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton_6
    del _BuildAutomaton_6
    import pyxb.utils.fac as fac

    counters = set()
    cc_0 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 55, 3))
    counters.add(cc_0)
    cc_1 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 56, 3))
    counters.add(cc_1)
    cc_2 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 57, 3))
    counters.add(cc_2)
    cc_3 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 28, 5))
    counters.add(cc_3)
    cc_4 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 29, 5))
    counters.add(cc_4)
    cc_5 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 61, 20))
    counters.add(cc_5)
    cc_6 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 62, 20))
    counters.add(cc_6)
    cc_7 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 94, 20))
    counters.add(cc_7)
    cc_8 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 95, 20))
    counters.add(cc_8)
    cc_9 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 96, 20))
    counters.add(cc_9)
    cc_10 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 97, 20))
    counters.add(cc_10)
    cc_11 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 98, 20))
    counters.add(cc_11)
    states = []
    final_update = None
    symbol = pyxb.binding.content.ElementUse(AbstractTextureType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'metaDataProperty')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 55, 3))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(AbstractTextureType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'description')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 56, 3))
    st_1 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_1)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(AbstractTextureType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'name')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 57, 3))
    st_2 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_2)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(AbstractTextureType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'boundedBy')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 28, 5))
    st_3 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_3)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(AbstractTextureType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'location')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 29, 5))
    st_4 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_4)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(AbstractTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'isFront')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 61, 20))
    st_5 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_5)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(AbstractTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfSurfaceData')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 62, 20))
    st_6 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_6)
    final_update = set()
    symbol = pyxb.binding.content.ElementUse(AbstractTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'imageURI')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 93, 20))
    st_7 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_7)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_7, False))
    symbol = pyxb.binding.content.ElementUse(AbstractTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'mimeType')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 94, 20))
    st_8 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_8)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_8, False))
    symbol = pyxb.binding.content.ElementUse(AbstractTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'textureType')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 95, 20))
    st_9 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_9)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_9, False))
    symbol = pyxb.binding.content.ElementUse(AbstractTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'wrapMode')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 96, 20))
    st_10 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_10)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_10, False))
    symbol = pyxb.binding.content.ElementUse(AbstractTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'borderColor')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 97, 20))
    st_11 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_11)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_11, False))
    symbol = pyxb.binding.content.ElementUse(AbstractTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfTexture')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 98, 20))
    st_12 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_12)
    transitions = []
    transitions.append(fac.Transition(st_0, [
        fac.UpdateInstruction(cc_0, True) ]))
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_0, False) ]))
    st_0._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_1, True) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_1, False) ]))
    st_1._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_2, True) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_2, False) ]))
    st_2._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_3, True) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_3, False) ]))
    st_3._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_4, True) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_4, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_4, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_4, False) ]))
    st_4._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_5, True) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_5, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_5, False) ]))
    st_5._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_6, True) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_6, False) ]))
    st_6._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_8, [
         ]))
    transitions.append(fac.Transition(st_9, [
         ]))
    transitions.append(fac.Transition(st_10, [
         ]))
    transitions.append(fac.Transition(st_11, [
         ]))
    transitions.append(fac.Transition(st_12, [
         ]))
    st_7._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_8, [
        fac.UpdateInstruction(cc_7, True) ]))
    transitions.append(fac.Transition(st_9, [
        fac.UpdateInstruction(cc_7, False) ]))
    transitions.append(fac.Transition(st_10, [
        fac.UpdateInstruction(cc_7, False) ]))
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_7, False) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_7, False) ]))
    st_8._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_9, [
        fac.UpdateInstruction(cc_8, True) ]))
    transitions.append(fac.Transition(st_10, [
        fac.UpdateInstruction(cc_8, False) ]))
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_8, False) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_8, False) ]))
    st_9._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_10, [
        fac.UpdateInstruction(cc_9, True) ]))
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_9, False) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_9, False) ]))
    st_10._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_10, True) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_10, False) ]))
    st_11._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_11, True) ]))
    st_12._set_transitionSet(transitions)
    return fac.Automaton(states, counters, False, containing_state=None)
AbstractTextureType._Automaton = _BuildAutomaton_6()




TexCoordListType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'textureCoordinates'), CTD_ANON, scope=TexCoordListType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 216, 20)))

TexCoordListType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfTexCoordList'), pyxb.binding.datatypes.anyType, abstract=pyxb.binding.datatypes.boolean(1), scope=TexCoordListType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 233, 4)))

def _BuildAutomaton_7 ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton_7
    del _BuildAutomaton_7
    import pyxb.utils.fac as fac

    counters = set()
    cc_0 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 55, 3))
    counters.add(cc_0)
    cc_1 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 56, 3))
    counters.add(cc_1)
    cc_2 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 57, 3))
    counters.add(cc_2)
    cc_3 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 194, 20))
    counters.add(cc_3)
    cc_4 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 225, 20))
    counters.add(cc_4)
    states = []
    final_update = None
    symbol = pyxb.binding.content.ElementUse(TexCoordListType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'metaDataProperty')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 55, 3))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(TexCoordListType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'description')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 56, 3))
    st_1 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_1)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(TexCoordListType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'name')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 57, 3))
    st_2 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_2)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(TexCoordListType._UseForTag(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfTextureParameterization')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 194, 20))
    st_3 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_3)
    final_update = set()
    symbol = pyxb.binding.content.ElementUse(TexCoordListType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'textureCoordinates')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 216, 20))
    st_4 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_4)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_4, False))
    symbol = pyxb.binding.content.ElementUse(TexCoordListType._UseForTag(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfTexCoordList')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 225, 20))
    st_5 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_5)
    transitions = []
    transitions.append(fac.Transition(st_0, [
        fac.UpdateInstruction(cc_0, True) ]))
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_0, False) ]))
    st_0._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_1, True) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_1, False) ]))
    st_1._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_2, True) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_2, False) ]))
    st_2._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_3, True) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_3, False) ]))
    st_3._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_4, [
         ]))
    transitions.append(fac.Transition(st_5, [
         ]))
    st_4._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_4, True) ]))
    st_5._set_transitionSet(transitions)
    return fac.Automaton(states, counters, False, containing_state=None)
TexCoordListType._Automaton = _BuildAutomaton_7()




TexCoordGenType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'worldToTexture'), CTD_ANON_, scope=TexCoordGenType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 247, 20)))

TexCoordGenType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfTexCoordGen'), pyxb.binding.datatypes.anyType, abstract=pyxb.binding.datatypes.boolean(1), scope=TexCoordGenType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 264, 4)))

def _BuildAutomaton_8 ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton_8
    del _BuildAutomaton_8
    import pyxb.utils.fac as fac

    counters = set()
    cc_0 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 55, 3))
    counters.add(cc_0)
    cc_1 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 56, 3))
    counters.add(cc_1)
    cc_2 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 57, 3))
    counters.add(cc_2)
    cc_3 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 194, 20))
    counters.add(cc_3)
    cc_4 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 256, 20))
    counters.add(cc_4)
    states = []
    final_update = None
    symbol = pyxb.binding.content.ElementUse(TexCoordGenType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'metaDataProperty')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 55, 3))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(TexCoordGenType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'description')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 56, 3))
    st_1 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_1)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(TexCoordGenType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'name')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 57, 3))
    st_2 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_2)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(TexCoordGenType._UseForTag(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfTextureParameterization')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 194, 20))
    st_3 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_3)
    final_update = set()
    symbol = pyxb.binding.content.ElementUse(TexCoordGenType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'worldToTexture')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 247, 20))
    st_4 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_4)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_4, False))
    symbol = pyxb.binding.content.ElementUse(TexCoordGenType._UseForTag(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfTexCoordGen')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 256, 20))
    st_5 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_5)
    transitions = []
    transitions.append(fac.Transition(st_0, [
        fac.UpdateInstruction(cc_0, True) ]))
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_0, False) ]))
    st_0._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_1, True) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_1, False) ]))
    st_1._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_2, True) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_2, False) ]))
    st_2._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_3, True) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_3, False) ]))
    st_3._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_5, [
         ]))
    st_4._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_4, True) ]))
    st_5._set_transitionSet(transitions)
    return fac.Automaton(states, counters, False, containing_state=None)
TexCoordGenType._Automaton = _BuildAutomaton_8()




X3DMaterialType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'ambientIntensity'), pyxb.bundles.opengis.citygml.base.doubleBetween0and1, scope=X3DMaterialType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 276, 20), unicode_default='0.2'))

X3DMaterialType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'diffuseColor'), Color, scope=X3DMaterialType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 277, 20), unicode_default='0.8 0.8 0.8'))

X3DMaterialType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'emissiveColor'), Color, scope=X3DMaterialType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 278, 20), unicode_default='0.0 0.0 0.0'))

X3DMaterialType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'specularColor'), Color, scope=X3DMaterialType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 279, 20), unicode_default='1.0 1.0 1.0'))

X3DMaterialType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'shininess'), pyxb.bundles.opengis.citygml.base.doubleBetween0and1, scope=X3DMaterialType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 280, 20), unicode_default='0.2'))

X3DMaterialType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'transparency'), pyxb.bundles.opengis.citygml.base.doubleBetween0and1, scope=X3DMaterialType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 281, 20), unicode_default='0.0'))

X3DMaterialType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'isSmooth'), pyxb.binding.datatypes.boolean, scope=X3DMaterialType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 282, 20), unicode_default='false'))

X3DMaterialType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'target'), pyxb.binding.datatypes.anyURI, scope=X3DMaterialType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 283, 20)))

X3DMaterialType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfX3DMaterial'), pyxb.binding.datatypes.anyType, abstract=pyxb.binding.datatypes.boolean(1), scope=X3DMaterialType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 292, 4)))

def _BuildAutomaton_9 ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton_9
    del _BuildAutomaton_9
    import pyxb.utils.fac as fac

    counters = set()
    cc_0 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 55, 3))
    counters.add(cc_0)
    cc_1 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 56, 3))
    counters.add(cc_1)
    cc_2 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 57, 3))
    counters.add(cc_2)
    cc_3 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 28, 5))
    counters.add(cc_3)
    cc_4 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 29, 5))
    counters.add(cc_4)
    cc_5 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 61, 20))
    counters.add(cc_5)
    cc_6 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 62, 20))
    counters.add(cc_6)
    cc_7 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 276, 20))
    counters.add(cc_7)
    cc_8 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 277, 20))
    counters.add(cc_8)
    cc_9 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 278, 20))
    counters.add(cc_9)
    cc_10 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 279, 20))
    counters.add(cc_10)
    cc_11 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 280, 20))
    counters.add(cc_11)
    cc_12 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 281, 20))
    counters.add(cc_12)
    cc_13 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 282, 20))
    counters.add(cc_13)
    cc_14 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 283, 20))
    counters.add(cc_14)
    cc_15 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 284, 20))
    counters.add(cc_15)
    states = []
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_0, False))
    symbol = pyxb.binding.content.ElementUse(X3DMaterialType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'metaDataProperty')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 55, 3))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_1, False))
    symbol = pyxb.binding.content.ElementUse(X3DMaterialType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'description')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 56, 3))
    st_1 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_1)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_2, False))
    symbol = pyxb.binding.content.ElementUse(X3DMaterialType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'name')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 57, 3))
    st_2 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_2)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_3, False))
    symbol = pyxb.binding.content.ElementUse(X3DMaterialType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'boundedBy')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 28, 5))
    st_3 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_3)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_4, False))
    symbol = pyxb.binding.content.ElementUse(X3DMaterialType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'location')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 29, 5))
    st_4 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_4)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_5, False))
    symbol = pyxb.binding.content.ElementUse(X3DMaterialType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'isFront')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 61, 20))
    st_5 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_5)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_6, False))
    symbol = pyxb.binding.content.ElementUse(X3DMaterialType._UseForTag(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfSurfaceData')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 62, 20))
    st_6 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_6)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_7, False))
    symbol = pyxb.binding.content.ElementUse(X3DMaterialType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'ambientIntensity')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 276, 20))
    st_7 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_7)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_8, False))
    symbol = pyxb.binding.content.ElementUse(X3DMaterialType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'diffuseColor')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 277, 20))
    st_8 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_8)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_9, False))
    symbol = pyxb.binding.content.ElementUse(X3DMaterialType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'emissiveColor')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 278, 20))
    st_9 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_9)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_10, False))
    symbol = pyxb.binding.content.ElementUse(X3DMaterialType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'specularColor')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 279, 20))
    st_10 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_10)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_11, False))
    symbol = pyxb.binding.content.ElementUse(X3DMaterialType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'shininess')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 280, 20))
    st_11 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_11)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_12, False))
    symbol = pyxb.binding.content.ElementUse(X3DMaterialType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'transparency')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 281, 20))
    st_12 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_12)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_13, False))
    symbol = pyxb.binding.content.ElementUse(X3DMaterialType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'isSmooth')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 282, 20))
    st_13 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_13)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_14, False))
    symbol = pyxb.binding.content.ElementUse(X3DMaterialType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'target')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 283, 20))
    st_14 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_14)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_15, False))
    symbol = pyxb.binding.content.ElementUse(X3DMaterialType._UseForTag(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfX3DMaterial')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 284, 20))
    st_15 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_15)
    transitions = []
    transitions.append(fac.Transition(st_0, [
        fac.UpdateInstruction(cc_0, True) ]))
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_8, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_9, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_10, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_0, False) ]))
    st_0._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_1, True) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_8, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_9, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_10, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_1, False) ]))
    st_1._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_2, True) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_8, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_9, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_10, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_2, False) ]))
    st_2._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_3, True) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_8, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_9, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_10, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_3, False) ]))
    st_3._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_4, True) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_4, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_4, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_4, False) ]))
    transitions.append(fac.Transition(st_8, [
        fac.UpdateInstruction(cc_4, False) ]))
    transitions.append(fac.Transition(st_9, [
        fac.UpdateInstruction(cc_4, False) ]))
    transitions.append(fac.Transition(st_10, [
        fac.UpdateInstruction(cc_4, False) ]))
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_4, False) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_4, False) ]))
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_4, False) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_4, False) ]))
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_4, False) ]))
    st_4._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_5, True) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_5, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_5, False) ]))
    transitions.append(fac.Transition(st_8, [
        fac.UpdateInstruction(cc_5, False) ]))
    transitions.append(fac.Transition(st_9, [
        fac.UpdateInstruction(cc_5, False) ]))
    transitions.append(fac.Transition(st_10, [
        fac.UpdateInstruction(cc_5, False) ]))
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_5, False) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_5, False) ]))
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_5, False) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_5, False) ]))
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_5, False) ]))
    st_5._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_6, True) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_6, False) ]))
    transitions.append(fac.Transition(st_8, [
        fac.UpdateInstruction(cc_6, False) ]))
    transitions.append(fac.Transition(st_9, [
        fac.UpdateInstruction(cc_6, False) ]))
    transitions.append(fac.Transition(st_10, [
        fac.UpdateInstruction(cc_6, False) ]))
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_6, False) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_6, False) ]))
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_6, False) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_6, False) ]))
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_6, False) ]))
    st_6._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_7, True) ]))
    transitions.append(fac.Transition(st_8, [
        fac.UpdateInstruction(cc_7, False) ]))
    transitions.append(fac.Transition(st_9, [
        fac.UpdateInstruction(cc_7, False) ]))
    transitions.append(fac.Transition(st_10, [
        fac.UpdateInstruction(cc_7, False) ]))
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_7, False) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_7, False) ]))
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_7, False) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_7, False) ]))
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_7, False) ]))
    st_7._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_8, [
        fac.UpdateInstruction(cc_8, True) ]))
    transitions.append(fac.Transition(st_9, [
        fac.UpdateInstruction(cc_8, False) ]))
    transitions.append(fac.Transition(st_10, [
        fac.UpdateInstruction(cc_8, False) ]))
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_8, False) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_8, False) ]))
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_8, False) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_8, False) ]))
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_8, False) ]))
    st_8._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_9, [
        fac.UpdateInstruction(cc_9, True) ]))
    transitions.append(fac.Transition(st_10, [
        fac.UpdateInstruction(cc_9, False) ]))
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_9, False) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_9, False) ]))
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_9, False) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_9, False) ]))
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_9, False) ]))
    st_9._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_10, [
        fac.UpdateInstruction(cc_10, True) ]))
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_10, False) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_10, False) ]))
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_10, False) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_10, False) ]))
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_10, False) ]))
    st_10._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_11, True) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_11, False) ]))
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_11, False) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_11, False) ]))
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_11, False) ]))
    st_11._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_12, True) ]))
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_12, False) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_12, False) ]))
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_12, False) ]))
    st_12._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_13, True) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_13, False) ]))
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_13, False) ]))
    st_13._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_14, True) ]))
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_14, False) ]))
    st_14._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_15, True) ]))
    st_15._set_transitionSet(transitions)
    return fac.Automaton(states, counters, True, containing_state=None)
X3DMaterialType._Automaton = _BuildAutomaton_9()




ParameterizedTextureType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'target'), TextureAssociationType, scope=ParameterizedTextureType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 131, 20)))

ParameterizedTextureType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfParameterizedTexture'), pyxb.binding.datatypes.anyType, abstract=pyxb.binding.datatypes.boolean(1), scope=ParameterizedTextureType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 140, 4)))

def _BuildAutomaton_10 ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton_10
    del _BuildAutomaton_10
    import pyxb.utils.fac as fac

    counters = set()
    cc_0 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 55, 3))
    counters.add(cc_0)
    cc_1 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 56, 3))
    counters.add(cc_1)
    cc_2 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 57, 3))
    counters.add(cc_2)
    cc_3 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 28, 5))
    counters.add(cc_3)
    cc_4 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 29, 5))
    counters.add(cc_4)
    cc_5 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 61, 20))
    counters.add(cc_5)
    cc_6 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 62, 20))
    counters.add(cc_6)
    cc_7 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 94, 20))
    counters.add(cc_7)
    cc_8 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 95, 20))
    counters.add(cc_8)
    cc_9 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 96, 20))
    counters.add(cc_9)
    cc_10 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 97, 20))
    counters.add(cc_10)
    cc_11 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 98, 20))
    counters.add(cc_11)
    cc_12 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 131, 20))
    counters.add(cc_12)
    cc_13 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 132, 20))
    counters.add(cc_13)
    states = []
    final_update = None
    symbol = pyxb.binding.content.ElementUse(ParameterizedTextureType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'metaDataProperty')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 55, 3))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(ParameterizedTextureType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'description')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 56, 3))
    st_1 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_1)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(ParameterizedTextureType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'name')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 57, 3))
    st_2 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_2)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(ParameterizedTextureType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'boundedBy')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 28, 5))
    st_3 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_3)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(ParameterizedTextureType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'location')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 29, 5))
    st_4 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_4)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(ParameterizedTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'isFront')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 61, 20))
    st_5 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_5)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(ParameterizedTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfSurfaceData')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 62, 20))
    st_6 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_6)
    final_update = set()
    symbol = pyxb.binding.content.ElementUse(ParameterizedTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'imageURI')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 93, 20))
    st_7 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_7)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_7, False))
    symbol = pyxb.binding.content.ElementUse(ParameterizedTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'mimeType')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 94, 20))
    st_8 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_8)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_8, False))
    symbol = pyxb.binding.content.ElementUse(ParameterizedTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'textureType')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 95, 20))
    st_9 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_9)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_9, False))
    symbol = pyxb.binding.content.ElementUse(ParameterizedTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'wrapMode')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 96, 20))
    st_10 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_10)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_10, False))
    symbol = pyxb.binding.content.ElementUse(ParameterizedTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'borderColor')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 97, 20))
    st_11 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_11)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_11, False))
    symbol = pyxb.binding.content.ElementUse(ParameterizedTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfTexture')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 98, 20))
    st_12 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_12)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_12, False))
    symbol = pyxb.binding.content.ElementUse(ParameterizedTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'target')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 131, 20))
    st_13 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_13)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_13, False))
    symbol = pyxb.binding.content.ElementUse(ParameterizedTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfParameterizedTexture')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 132, 20))
    st_14 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_14)
    transitions = []
    transitions.append(fac.Transition(st_0, [
        fac.UpdateInstruction(cc_0, True) ]))
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_0, False) ]))
    st_0._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_1, True) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_1, False) ]))
    st_1._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_2, True) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_2, False) ]))
    st_2._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_3, True) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_3, False) ]))
    st_3._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_4, True) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_4, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_4, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_4, False) ]))
    st_4._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_5, True) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_5, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_5, False) ]))
    st_5._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_6, True) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_6, False) ]))
    st_6._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_8, [
         ]))
    transitions.append(fac.Transition(st_9, [
         ]))
    transitions.append(fac.Transition(st_10, [
         ]))
    transitions.append(fac.Transition(st_11, [
         ]))
    transitions.append(fac.Transition(st_12, [
         ]))
    transitions.append(fac.Transition(st_13, [
         ]))
    transitions.append(fac.Transition(st_14, [
         ]))
    st_7._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_8, [
        fac.UpdateInstruction(cc_7, True) ]))
    transitions.append(fac.Transition(st_9, [
        fac.UpdateInstruction(cc_7, False) ]))
    transitions.append(fac.Transition(st_10, [
        fac.UpdateInstruction(cc_7, False) ]))
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_7, False) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_7, False) ]))
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_7, False) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_7, False) ]))
    st_8._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_9, [
        fac.UpdateInstruction(cc_8, True) ]))
    transitions.append(fac.Transition(st_10, [
        fac.UpdateInstruction(cc_8, False) ]))
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_8, False) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_8, False) ]))
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_8, False) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_8, False) ]))
    st_9._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_10, [
        fac.UpdateInstruction(cc_9, True) ]))
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_9, False) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_9, False) ]))
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_9, False) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_9, False) ]))
    st_10._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_10, True) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_10, False) ]))
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_10, False) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_10, False) ]))
    st_11._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_11, True) ]))
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_11, False) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_11, False) ]))
    st_12._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_12, True) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_12, False) ]))
    st_13._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_13, True) ]))
    st_14._set_transitionSet(transitions)
    return fac.Automaton(states, counters, False, containing_state=None)
ParameterizedTextureType._Automaton = _BuildAutomaton_10()




GeoreferencedTextureType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'preferWorldFile'), pyxb.binding.datatypes.boolean, scope=GeoreferencedTextureType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 158, 20), unicode_default='true'))

GeoreferencedTextureType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'referencePoint'), pyxb.bundles.opengis.gml.PointPropertyType, scope=GeoreferencedTextureType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 159, 20)))

GeoreferencedTextureType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'orientation'), pyxb.bundles.opengis.citygml.base.TransformationMatrix2x2Type, scope=GeoreferencedTextureType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 160, 20)))

GeoreferencedTextureType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, 'target'), pyxb.binding.datatypes.anyURI, scope=GeoreferencedTextureType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 161, 20)))

GeoreferencedTextureType._AddElement(pyxb.binding.basis.element(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfGeoreferencedTexture'), pyxb.binding.datatypes.anyType, abstract=pyxb.binding.datatypes.boolean(1), scope=GeoreferencedTextureType, location=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 170, 4)))

def _BuildAutomaton_11 ():
    # Remove this helper function from the namespace after it is invoked
    global _BuildAutomaton_11
    del _BuildAutomaton_11
    import pyxb.utils.fac as fac

    counters = set()
    cc_0 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 55, 3))
    counters.add(cc_0)
    cc_1 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 56, 3))
    counters.add(cc_1)
    cc_2 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 57, 3))
    counters.add(cc_2)
    cc_3 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 28, 5))
    counters.add(cc_3)
    cc_4 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 29, 5))
    counters.add(cc_4)
    cc_5 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 61, 20))
    counters.add(cc_5)
    cc_6 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 62, 20))
    counters.add(cc_6)
    cc_7 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 94, 20))
    counters.add(cc_7)
    cc_8 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 95, 20))
    counters.add(cc_8)
    cc_9 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 96, 20))
    counters.add(cc_9)
    cc_10 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 97, 20))
    counters.add(cc_10)
    cc_11 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 98, 20))
    counters.add(cc_11)
    cc_12 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 158, 20))
    counters.add(cc_12)
    cc_13 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 159, 20))
    counters.add(cc_13)
    cc_14 = fac.CounterCondition(min=0, max=1, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 160, 20))
    counters.add(cc_14)
    cc_15 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 161, 20))
    counters.add(cc_15)
    cc_16 = fac.CounterCondition(min=0, max=None, metadata=pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 162, 20))
    counters.add(cc_16)
    states = []
    final_update = None
    symbol = pyxb.binding.content.ElementUse(GeoreferencedTextureType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'metaDataProperty')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 55, 3))
    st_0 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_0)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(GeoreferencedTextureType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'description')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 56, 3))
    st_1 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_1)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(GeoreferencedTextureType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'name')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/gmlBase.xsd', 57, 3))
    st_2 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_2)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(GeoreferencedTextureType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'boundedBy')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 28, 5))
    st_3 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_3)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(GeoreferencedTextureType._UseForTag(pyxb.namespace.ExpandedName(_Namespace_gml, 'location')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/gml/3.1.1/base/feature.xsd', 29, 5))
    st_4 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_4)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(GeoreferencedTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'isFront')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 61, 20))
    st_5 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_5)
    final_update = None
    symbol = pyxb.binding.content.ElementUse(GeoreferencedTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfSurfaceData')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 62, 20))
    st_6 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_6)
    final_update = set()
    symbol = pyxb.binding.content.ElementUse(GeoreferencedTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'imageURI')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 93, 20))
    st_7 = fac.State(symbol, is_initial=True, final_update=final_update, is_unordered_catenation=False)
    states.append(st_7)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_7, False))
    symbol = pyxb.binding.content.ElementUse(GeoreferencedTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'mimeType')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 94, 20))
    st_8 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_8)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_8, False))
    symbol = pyxb.binding.content.ElementUse(GeoreferencedTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'textureType')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 95, 20))
    st_9 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_9)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_9, False))
    symbol = pyxb.binding.content.ElementUse(GeoreferencedTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'wrapMode')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 96, 20))
    st_10 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_10)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_10, False))
    symbol = pyxb.binding.content.ElementUse(GeoreferencedTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'borderColor')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 97, 20))
    st_11 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_11)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_11, False))
    symbol = pyxb.binding.content.ElementUse(GeoreferencedTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfTexture')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 98, 20))
    st_12 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_12)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_12, False))
    symbol = pyxb.binding.content.ElementUse(GeoreferencedTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'preferWorldFile')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 158, 20))
    st_13 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_13)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_13, False))
    symbol = pyxb.binding.content.ElementUse(GeoreferencedTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'referencePoint')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 159, 20))
    st_14 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_14)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_14, False))
    symbol = pyxb.binding.content.ElementUse(GeoreferencedTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'orientation')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 160, 20))
    st_15 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_15)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_15, False))
    symbol = pyxb.binding.content.ElementUse(GeoreferencedTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, 'target')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 161, 20))
    st_16 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_16)
    final_update = set()
    final_update.add(fac.UpdateInstruction(cc_16, False))
    symbol = pyxb.binding.content.ElementUse(GeoreferencedTextureType._UseForTag(pyxb.namespace.ExpandedName(Namespace, '_GenericApplicationPropertyOfGeoreferencedTexture')), pyxb.utils.utility.Location('/home/rodney_marsh/source/pyxb/pyxb/bundles/opengis/schemas/citygml/appearance/1.0/appearance.xsd', 162, 20))
    st_17 = fac.State(symbol, is_initial=False, final_update=final_update, is_unordered_catenation=False)
    states.append(st_17)
    transitions = []
    transitions.append(fac.Transition(st_0, [
        fac.UpdateInstruction(cc_0, True) ]))
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_0, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_0, False) ]))
    st_0._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_1, [
        fac.UpdateInstruction(cc_1, True) ]))
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_1, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_1, False) ]))
    st_1._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_2, [
        fac.UpdateInstruction(cc_2, True) ]))
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_2, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_2, False) ]))
    st_2._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_3, [
        fac.UpdateInstruction(cc_3, True) ]))
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_3, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_3, False) ]))
    st_3._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_4, [
        fac.UpdateInstruction(cc_4, True) ]))
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_4, False) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_4, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_4, False) ]))
    st_4._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_5, [
        fac.UpdateInstruction(cc_5, True) ]))
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_5, False) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_5, False) ]))
    st_5._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_6, [
        fac.UpdateInstruction(cc_6, True) ]))
    transitions.append(fac.Transition(st_7, [
        fac.UpdateInstruction(cc_6, False) ]))
    st_6._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_8, [
         ]))
    transitions.append(fac.Transition(st_9, [
         ]))
    transitions.append(fac.Transition(st_10, [
         ]))
    transitions.append(fac.Transition(st_11, [
         ]))
    transitions.append(fac.Transition(st_12, [
         ]))
    transitions.append(fac.Transition(st_13, [
         ]))
    transitions.append(fac.Transition(st_14, [
         ]))
    transitions.append(fac.Transition(st_15, [
         ]))
    transitions.append(fac.Transition(st_16, [
         ]))
    transitions.append(fac.Transition(st_17, [
         ]))
    st_7._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_8, [
        fac.UpdateInstruction(cc_7, True) ]))
    transitions.append(fac.Transition(st_9, [
        fac.UpdateInstruction(cc_7, False) ]))
    transitions.append(fac.Transition(st_10, [
        fac.UpdateInstruction(cc_7, False) ]))
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_7, False) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_7, False) ]))
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_7, False) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_7, False) ]))
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_7, False) ]))
    transitions.append(fac.Transition(st_16, [
        fac.UpdateInstruction(cc_7, False) ]))
    transitions.append(fac.Transition(st_17, [
        fac.UpdateInstruction(cc_7, False) ]))
    st_8._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_9, [
        fac.UpdateInstruction(cc_8, True) ]))
    transitions.append(fac.Transition(st_10, [
        fac.UpdateInstruction(cc_8, False) ]))
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_8, False) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_8, False) ]))
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_8, False) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_8, False) ]))
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_8, False) ]))
    transitions.append(fac.Transition(st_16, [
        fac.UpdateInstruction(cc_8, False) ]))
    transitions.append(fac.Transition(st_17, [
        fac.UpdateInstruction(cc_8, False) ]))
    st_9._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_10, [
        fac.UpdateInstruction(cc_9, True) ]))
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_9, False) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_9, False) ]))
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_9, False) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_9, False) ]))
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_9, False) ]))
    transitions.append(fac.Transition(st_16, [
        fac.UpdateInstruction(cc_9, False) ]))
    transitions.append(fac.Transition(st_17, [
        fac.UpdateInstruction(cc_9, False) ]))
    st_10._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_11, [
        fac.UpdateInstruction(cc_10, True) ]))
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_10, False) ]))
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_10, False) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_10, False) ]))
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_10, False) ]))
    transitions.append(fac.Transition(st_16, [
        fac.UpdateInstruction(cc_10, False) ]))
    transitions.append(fac.Transition(st_17, [
        fac.UpdateInstruction(cc_10, False) ]))
    st_11._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_12, [
        fac.UpdateInstruction(cc_11, True) ]))
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_11, False) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_11, False) ]))
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_11, False) ]))
    transitions.append(fac.Transition(st_16, [
        fac.UpdateInstruction(cc_11, False) ]))
    transitions.append(fac.Transition(st_17, [
        fac.UpdateInstruction(cc_11, False) ]))
    st_12._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_13, [
        fac.UpdateInstruction(cc_12, True) ]))
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_12, False) ]))
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_12, False) ]))
    transitions.append(fac.Transition(st_16, [
        fac.UpdateInstruction(cc_12, False) ]))
    transitions.append(fac.Transition(st_17, [
        fac.UpdateInstruction(cc_12, False) ]))
    st_13._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_14, [
        fac.UpdateInstruction(cc_13, True) ]))
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_13, False) ]))
    transitions.append(fac.Transition(st_16, [
        fac.UpdateInstruction(cc_13, False) ]))
    transitions.append(fac.Transition(st_17, [
        fac.UpdateInstruction(cc_13, False) ]))
    st_14._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_15, [
        fac.UpdateInstruction(cc_14, True) ]))
    transitions.append(fac.Transition(st_16, [
        fac.UpdateInstruction(cc_14, False) ]))
    transitions.append(fac.Transition(st_17, [
        fac.UpdateInstruction(cc_14, False) ]))
    st_15._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_16, [
        fac.UpdateInstruction(cc_15, True) ]))
    transitions.append(fac.Transition(st_17, [
        fac.UpdateInstruction(cc_15, False) ]))
    st_16._set_transitionSet(transitions)
    transitions = []
    transitions.append(fac.Transition(st_17, [
        fac.UpdateInstruction(cc_16, True) ]))
    st_17._set_transitionSet(transitions)
    return fac.Automaton(states, counters, False, containing_state=None)
GeoreferencedTextureType._Automaton = _BuildAutomaton_11()


appearanceMember._setSubstitutionGroup(pyxb.bundles.opengis.gml.featureMember)

appearance._setSubstitutionGroup(pyxb.bundles.opengis.citygml.base.GenericApplicationPropertyOfCityObject)

SurfaceData._setSubstitutionGroup(pyxb.bundles.opengis.gml.Feature)

TextureParameterization._setSubstitutionGroup(pyxb.bundles.opengis.gml.GML)

Texture._setSubstitutionGroup(SurfaceData)

TexCoordList._setSubstitutionGroup(TextureParameterization)

TexCoordGen._setSubstitutionGroup(TextureParameterization)

X3DMaterial._setSubstitutionGroup(SurfaceData)

ParameterizedTexture._setSubstitutionGroup(Texture)

GeoreferencedTexture._setSubstitutionGroup(Texture)
