from pyxb.bundles.wssplat.raw.wsdlx import *
