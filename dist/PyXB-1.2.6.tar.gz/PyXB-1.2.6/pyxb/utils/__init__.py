# -*- coding: utf-8 -*-
"""pyxb.utils -- Utilities for the PyWXSB package.
"""
