rm -f cablelabs.wxs
sh genbindings.sh \
  && python demo.py
