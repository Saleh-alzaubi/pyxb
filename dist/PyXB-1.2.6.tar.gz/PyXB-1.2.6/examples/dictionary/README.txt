The Dictionary web service at Aonaware (http://www.aonaware.com/services.htm)

Use genbindings.sh to retrieve the wsdl and generate the bindings for the
schema used in it.

Try showdict.py for an example of interacting with the service.  Sorry, no
automatic generation of classes corresponding to the WSDL operations.  Next
release, maybe.
