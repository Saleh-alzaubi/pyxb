This example reads the XML version of the formal part of the Unified
Code for Units of Measure specification.  It allows custom generation of
tables or other material based on UCUM.

See: http://unitsofmeasure.org/trac
