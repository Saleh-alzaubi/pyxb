NOTE: As of 2016-09-18 geocoder.us appears to be shut down.

A utility to look up the latitude and longitude of a US address.  See
http://geocoder.us.
