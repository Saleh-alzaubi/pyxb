Disabled 2015-04-20: site supplying schema is no longer reachable
