FGD_GMLSchema.xsd is originally from http://fgd.gsi.go.jp/download/.
(The Geospatial Information Authority of Japan (GSI).)

English pages is http://www.gsi.go.jp/ENGLISH/index.html, but i don't know to reach English download page.

Schema is written in Shift_JIS, and applications (GML 3.2.1) are also written in `Shift_JIS'.
(Shift_JIS -> code page 932 in UNICODE, python can process it both `Shift_JIS' and `cp932'.
Unfortunatelly, more dialect ... `Windows-31J' is also equal to `Shift_JIS'.)

I don't want to describe xml element(etc.) with Japanese, but they (people in GSI) does.

Because FG-GML-13-RailCL25000-20080331-0001.xml is 6316491 bytes, so I curtailed it.
