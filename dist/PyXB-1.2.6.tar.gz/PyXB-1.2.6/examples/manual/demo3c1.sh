pyxbgen \
  -u nsaddress.xsd -m address \
  --archive-to-file address.wxs
