pyxbgen \
  -u po3.xsd -m po3
