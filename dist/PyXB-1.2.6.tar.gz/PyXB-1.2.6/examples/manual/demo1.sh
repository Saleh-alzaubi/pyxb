pyxbgen \
  -u po1.xsd  -m po1
