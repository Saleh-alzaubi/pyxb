PyXB -- Python W3C XML Schema Bindings
Version 1.2.6

The source releases includes pre-built bundles for common XML namespaces,
assorted web service namespaces, and SAML.  A bundle with over 75 namespaces
related to Geographic Information Systems is also available; if you want
those, read pyxb/bundles/opengis/README.txt before installing PyXB.

Installation:  python setup.py install

Documentation: doc/html or https://pabigot.github.io/pyxb/

Help Forum: http://sourceforge.net/forum/forum.php?forum_id=956708

Mailing list: https://lists.sourceforge.net/lists/listinfo/pyxb-users
Archive: http://www.mail-archive.com/pyxb-users@lists.sourceforge.net

Bug reports: https://github.com/pabigot/pyxb/issues
