sh genbindings.sh
python dumpsample.py
