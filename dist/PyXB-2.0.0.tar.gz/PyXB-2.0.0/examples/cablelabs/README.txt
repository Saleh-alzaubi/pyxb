Updated 2014-02-05: The schema referenced by this example are no longer
available at the original URI.  If they are available elsewhere it's not
obvious.

This example was generated in response to a thread in the PyXB Help forum.

The thread may be viewed at:

https://sourceforge.net/projects/pyxb/forums/forum/956708/topic/5422611/

The primary purpose of the example is to allow you to see how the new
diagnostics supported in PyXB 1.2 vastly simplify the problem of generating
a valid document from unfamiliar bindings.
