changed encoding manually (with emacs. ;-)
