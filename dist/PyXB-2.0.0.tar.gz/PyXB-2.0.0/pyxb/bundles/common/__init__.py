"""In this module are stored generated bindings for standard schema
like WSDL or SOAP."""
