# -*- coding: utf-8 -*-
from pyxb.bundles.wssplat.raw.sawsdl import *
