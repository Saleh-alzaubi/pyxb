from pyxb.bundles.wssplat.raw.wsdli import *
